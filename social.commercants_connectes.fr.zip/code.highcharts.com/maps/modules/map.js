!(
  /**
   * Highcharts JS v12.3.0 (2025-06-21)
   * @module highcharts/modules/color-axis
   * @requires highcharts
   *
   * ColorAxis module
   *
   * (c) 2012-2025 Pawel Potaczek
   *
   * License: www.highcharts.com/license
   */ (function (t, e) {
    "object" == typeof exports && "object" == typeof module
      ? (module.exports = e(
          t._Highcharts,
          t._Highcharts.Axis,
          t._Highcharts.Color,
          t._Highcharts.LegendSymbol,
          t._Highcharts.SeriesRegistry,
          t._Highcharts.SVGElement,
          t._Highcharts.Series,
          t._Highcharts.Chart,
          t._Highcharts.SVGRenderer,
          t._Highcharts.Templating,
          t._Highcharts.Series.types.scatter,
          t._Highcharts.Point
        ))
      : "function" == typeof define && define.amd
      ? define(
          "highcharts/modules/map",
          ["highcharts/highcharts"],
          function (t) {
            return e(
              t,
              t.Axis,
              t.Color,
              t.LegendSymbol,
              t.SeriesRegistry,
              t.SVGElement,
              t.Series,
              t.Chart,
              t.SVGRenderer,
              t.Templating,
              t.Series,
              ["types"],
              ["scatter"],
              t.Point
            );
          }
        )
      : "object" == typeof exports
      ? (exports["highcharts/modules/map"] = e(
          t._Highcharts,
          t._Highcharts.Axis,
          t._Highcharts.Color,
          t._Highcharts.LegendSymbol,
          t._Highcharts.SeriesRegistry,
          t._Highcharts.SVGElement,
          t._Highcharts.Series,
          t._Highcharts.Chart,
          t._Highcharts.SVGRenderer,
          t._Highcharts.Templating,
          t._Highcharts.Series.types.scatter,
          t._Highcharts.Point
        ))
      : (t.Highcharts = e(
          t.Highcharts,
          t.Highcharts.Axis,
          t.Highcharts.Color,
          t.Highcharts.LegendSymbol,
          t.Highcharts.SeriesRegistry,
          t.Highcharts.SVGElement,
          t.Highcharts.Series,
          t.Highcharts.Chart,
          t.Highcharts.SVGRenderer,
          t.Highcharts.Templating,
          t.Highcharts.Series.types.scatter,
          t.Highcharts.Point
        ));
  })(
    "undefined" == typeof window ? this : window,
    (t, e, i, s, o, r, a, n, l, h, p, d) =>
      (() => {
        "use strict";
        let c;
        var u,
          m,
          g,
          f,
          b,
          y,
          x,
          M = {
            28: (t) => {
              t.exports = r;
            },
            260: (t) => {
              t.exports = d;
            },
            500: (t) => {
              t.exports = s;
            },
            512: (t) => {
              t.exports = o;
            },
            532: (t) => {
              t.exports = e;
            },
            540: (t) => {
              t.exports = l;
            },
            620: (t) => {
              t.exports = i;
            },
            632: (t) => {
              t.exports = p;
            },
            820: (t) => {
              t.exports = a;
            },
            944: (e) => {
              e.exports = t;
            },
            960: (t) => {
              t.exports = n;
            },
            984: (t) => {
              t.exports = h;
            },
          },
          v = {};
        function w(t) {
          var e = v[t];
          if (void 0 !== e) return e.exports;
          var i = (v[t] = { exports: {} });
          return M[t](i, i.exports, w), i.exports;
        }
        (w.n = (t) => {
          var e = t && t.__esModule ? () => t.default : () => t;
          return w.d(e, { a: e }), e;
        }),
          (w.d = (t, e) => {
            for (var i in e)
              w.o(e, i) &&
                !w.o(t, i) &&
                Object.defineProperty(t, i, { enumerable: !0, get: e[i] });
          }),
          (w.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e));
        var C = {};
        w.d(C, { default: () => sB });
        var T = w(944),
          L = w.n(T),
          P = w(532),
          A = w.n(P),
          k = w(620),
          j = w.n(k);
        let { parse: z } = j(),
          { addEvent: S, extend: I, merge: B, pick: E, splat: D } = L();
        !(function (t) {
          let e;
          function i() {
            let { userOptions: t } = this;
            (this.colorAxis = []),
              t.colorAxis &&
                ((t.colorAxis = D(t.colorAxis)),
                t.colorAxis.map((t) => new e(this, t)));
          }
          function s(t) {
            let e = this.chart.colorAxis || [],
              i = (e) => {
                let i = t.allItems.indexOf(e);
                -1 !== i &&
                  (this.destroyItem(t.allItems[i]), t.allItems.splice(i, 1));
              },
              s = [],
              o,
              r;
            for (
              e.forEach(function (t) {
                (o = t.options),
                  o?.showInLegend &&
                    (o.dataClasses && o.visible
                      ? (s = s.concat(t.getDataClassLegendSymbols()))
                      : o.visible && s.push(t),
                    t.series.forEach(function (t) {
                      (!t.options.showInLegend || o.dataClasses) &&
                        ("point" === t.options.legendType
                          ? t.points.forEach(function (t) {
                              i(t);
                            })
                          : i(t));
                    }));
              }),
                r = s.length;
              r--;

            )
              t.allItems.unshift(s[r]);
          }
          function o(t) {
            t.visible &&
              t.item.legendColor &&
              t.item.legendItem.symbol.attr({ fill: t.item.legendColor });
          }
          function r(t) {
            this.chart.colorAxis?.forEach((e) => {
              e.update({}, t.redraw);
            });
          }
          function a() {
            (this.chart.colorAxis?.length || this.colorAttribs) &&
              this.translateColors();
          }
          function n() {
            let t = this.axisTypes;
            t
              ? -1 === t.indexOf("colorAxis") && t.push("colorAxis")
              : (this.axisTypes = ["colorAxis"]);
          }
          function l(t) {
            let e = this,
              i = t ? "show" : "hide";
            (e.visible = e.options.visible = !!t),
              ["graphic", "dataLabel"].forEach(function (t) {
                e[t] && e[t][i]();
              }),
              this.series.buildKDTree();
          }
          function h() {
            let t = this,
              e = this.getPointsCollection(),
              i = this.options.nullColor,
              s = this.colorAxis,
              o = this.colorKey;
            e.forEach((e) => {
              let r = e.getNestedProperty(o),
                a =
                  e.options.color ||
                  (e.isNull || null === e.value
                    ? i
                    : s && void 0 !== r
                    ? s.toColor(r, e)
                    : e.color || t.color);
              a &&
                e.color !== a &&
                ((e.color = a),
                "point" === t.options.legendType &&
                  e.legendItem &&
                  e.legendItem.label &&
                  t.chart.legend.colorizeItem(e, e.visible));
            });
          }
          function p() {
            this.elem.attr(
              "fill",
              z(this.start).tweenTo(z(this.end), this.pos),
              void 0,
              !0
            );
          }
          function d() {
            this.elem.attr(
              "stroke",
              z(this.start).tweenTo(z(this.end), this.pos),
              void 0,
              !0
            );
          }
          (t.compose = function (t, c, u, m, g) {
            let f = c.prototype,
              b = u.prototype,
              y = g.prototype;
            f.collectionsWithUpdate.includes("colorAxis") ||
              ((e = t),
              f.collectionsWithUpdate.push("colorAxis"),
              (f.collectionsWithInit.colorAxis = [f.addColorAxis]),
              S(c, "afterCreateAxes", i),
              (function (t) {
                let i = t.prototype.createAxis;
                t.prototype.createAxis = function (t, s) {
                  if ("colorAxis" !== t) return i.apply(this, arguments);
                  let o = new e(
                    this,
                    B(s.axis, { index: this[t].length, isX: !1 })
                  );
                  return (
                    (this.isDirtyLegend = !0),
                    this.axes.forEach((t) => {
                      t.series = [];
                    }),
                    this.series.forEach((t) => {
                      t.bindAxes(), (t.isDirtyData = !0);
                    }),
                    E(s.redraw, !0) && this.redraw(s.animation),
                    o
                  );
                };
              })(c),
              (b.fillSetter = p),
              (b.strokeSetter = d),
              S(m, "afterGetAllItems", s),
              S(m, "afterColorizeItem", o),
              S(m, "afterUpdate", r),
              I(y, { optionalAxis: "colorAxis", translateColors: h }),
              I(y.pointClass.prototype, { setVisible: l }),
              S(g, "afterTranslate", a, { order: 1 }),
              S(g, "bindAxes", n));
          }),
            (t.pointSetVisible = l);
        })(u || (u = {}));
        let V = u,
          { parse: O } = j(),
          { merge: N } = L();
        !(function (t) {
          (t.initDataClasses = function (t) {
            let e = this.chart,
              i = (this.legendItem = this.legendItem || {}),
              s = this.options,
              o = t.dataClasses || [],
              r,
              a,
              n = e.options.chart.colorCount,
              l = 0,
              h;
            (this.dataClasses = a = []), (i.labels = []);
            for (let t = 0, i = o.length; t < i; ++t)
              (r = N((r = o[t]))),
                a.push(r),
                (e.styledMode || !r.color) &&
                  ("category" === s.dataClassColor
                    ? (e.styledMode ||
                        ((n = (h = e.options.colors || []).length),
                        (r.color = h[l])),
                      (r.colorIndex = l),
                      ++l === n && (l = 0))
                    : (r.color = O(s.minColor).tweenTo(
                        O(s.maxColor),
                        i < 2 ? 0.5 : t / (i - 1)
                      )));
          }),
            (t.initStops = function () {
              let t = this.options,
                e = (this.stops = t.stops || [
                  [0, t.minColor || ""],
                  [1, t.maxColor || ""],
                ]);
              for (let t = 0, i = e.length; t < i; ++t) e[t].color = O(e[t][1]);
            }),
            (t.normalizedValue = function (t) {
              let e = this.max || 0,
                i = this.min || 0;
              return (
                this.logarithmic && (t = this.logarithmic.log2lin(t)),
                1 - (e - t) / (e - i || 1)
              );
            }),
            (t.toColor = function (t, e) {
              let i,
                s,
                o,
                r,
                a,
                n,
                l = this.dataClasses,
                h = this.stops;
              if (l) {
                for (n = l.length; n--; )
                  if (
                    ((s = (a = l[n]).from),
                    (o = a.to),
                    (void 0 === s || t >= s) && (void 0 === o || t <= o))
                  ) {
                    (r = a.color),
                      e && ((e.dataClass = n), (e.colorIndex = a.colorIndex));
                    break;
                  }
              } else {
                for (
                  i = this.normalizedValue(t), n = h.length;
                  n-- && !(i > h[n][0]);

                );
                (s = h[n] || h[n + 1]),
                  (i = 1 - ((o = h[n + 1] || s)[0] - i) / (o[0] - s[0] || 1)),
                  (r = s.color.tweenTo(o.color, i));
              }
              return r;
            });
        })(m || (m = {}));
        let G = m;
        var X = w(500),
          R = w.n(X),
          H = w(512),
          W = w.n(H);
        let { defaultOptions: Y } = L(),
          { series: U } = W(),
          {
            defined: F,
            extend: Z,
            fireEvent: _,
            isArray: K,
            isNumber: q,
            merge: $,
            pick: J,
            relativeLength: Q,
          } = L();
        Y.colorAxis = $(Y.xAxis, {
          lineWidth: 0,
          minPadding: 0,
          maxPadding: 0,
          gridLineColor: "#ffffff",
          gridLineWidth: 1,
          tickPixelInterval: 72,
          startOnTick: !0,
          endOnTick: !0,
          offset: 0,
          marker: {
            animation: { duration: 50 },
            width: 0.01,
            color: "#999999",
          },
          labels: { distance: 8, overflow: "justify", rotation: 0 },
          minColor: "#e6e9ff",
          maxColor: "#0022ff",
          tickLength: 5,
          showInLegend: !0,
        });
        class tt extends A() {
          static compose(t, e, i, s) {
            V.compose(tt, t, e, i, s);
          }
          constructor(t, e) {
            super(t, e),
              (this.coll = "colorAxis"),
              (this.visible = !0),
              this.init(t, e);
          }
          init(t, e) {
            let i = t.options.legend || {},
              s = e.layout ? "vertical" !== e.layout : "vertical" !== i.layout;
            (this.side = e.side || s ? 2 : 1),
              (this.reversed = e.reversed || !s),
              (this.opposite = !s),
              super.init(t, e, "colorAxis"),
              (this.userOptions = e),
              K(t.userOptions.colorAxis) &&
                (t.userOptions.colorAxis[this.index] = e),
              e.dataClasses && this.initDataClasses(e),
              this.initStops(),
              (this.horiz = s),
              (this.zoomEnabled = !1);
          }
          hasData() {
            return !!(this.tickPositions || []).length;
          }
          setTickPositions() {
            if (!this.dataClasses) return super.setTickPositions();
          }
          setOptions(t) {
            let e = $(Y.colorAxis, t, {
              showEmpty: !1,
              title: null,
              visible: this.chart.options.legend.enabled && !1 !== t.visible,
            });
            super.setOptions(e), (this.options.crosshair = this.options.marker);
          }
          setAxisSize() {
            let t = this.chart,
              e = this.legendItem?.symbol,
              { width: i, height: s } = this.getSize();
            e &&
              ((this.left = +e.attr("x")),
              (this.top = +e.attr("y")),
              (this.width = i = +e.attr("width")),
              (this.height = s = +e.attr("height")),
              (this.right = t.chartWidth - this.left - i),
              (this.bottom = t.chartHeight - this.top - s),
              (this.pos = this.horiz ? this.left : this.top)),
              (this.len = (this.horiz ? i : s) || tt.defaultLegendLength);
          }
          getOffset() {
            let t = this.legendItem?.group,
              e = this.chart.axisOffset[this.side];
            if (t) {
              (this.axisParent = t), super.getOffset();
              let i = this.chart.legend;
              i.allItems.forEach(function (t) {
                t instanceof tt && t.drawLegendSymbol(i, t);
              }),
                i.render(),
                this.chart.getMargins(!0),
                this.chart.series.some((t) => t.isDrilling) ||
                  (this.isDirty = !0),
                this.added ||
                  ((this.added = !0),
                  (this.labelLeft = 0),
                  (this.labelRight = this.width)),
                (this.chart.axisOffset[this.side] = e);
            }
          }
          setLegendColor() {
            let t = this.horiz,
              e = this.reversed,
              i = +!!e,
              s = +!e,
              o = t ? [i, 0, s, 0] : [0, s, 0, i];
            this.legendColor = {
              linearGradient: { x1: o[0], y1: o[1], x2: o[2], y2: o[3] },
              stops: this.stops,
            };
          }
          drawLegendSymbol(t, e) {
            let i = e.legendItem || {},
              s = t.padding,
              o = t.options,
              r = this.options.labels,
              a = J(o.itemDistance, 10),
              n = this.horiz,
              { width: l, height: h } = this.getSize(),
              p = J(o.labelPadding, n ? 16 : 30);
            this.setLegendColor(),
              i.symbol ||
                (i.symbol = this.chart.renderer
                  .symbol("roundedRect")
                  .attr({ r: o.symbolRadius ?? 3, zIndex: 1 })
                  .add(i.group)),
              i.symbol.attr({
                x: 0,
                y: (t.baseline || 0) - 11,
                width: l,
                height: h,
              }),
              (i.labelWidth =
                l +
                s +
                (n ? a : J(r.x, r.distance) + (this.maxLabelLength || 0))),
              (i.labelHeight = h + s + (n ? p : 0));
          }
          setState(t) {
            this.series.forEach(function (e) {
              e.setState(t);
            });
          }
          setVisible() {}
          getSeriesExtremes() {
            let t = this.series,
              e,
              i,
              s,
              o,
              r = t.length;
            for (this.dataMin = 1 / 0, this.dataMax = -1 / 0; r--; ) {
              for (let a of ((i = (o = t[r]).colorKey =
                J(
                  o.options.colorKey,
                  o.colorKey,
                  o.pointValKey,
                  o.zoneAxis,
                  "y"
                )),
              (s = o[i + "Min"] && o[i + "Max"]),
              [i, "value", "y"]))
                if ((e = o.getColumn(a)).length) break;
              if (s)
                (o.minColorValue = o[i + "Min"]),
                  (o.maxColorValue = o[i + "Max"]);
              else {
                let t = U.prototype.getExtremes.call(o, e);
                (o.minColorValue = t.dataMin), (o.maxColorValue = t.dataMax);
              }
              F(o.minColorValue) &&
                F(o.maxColorValue) &&
                ((this.dataMin = Math.min(this.dataMin, o.minColorValue)),
                (this.dataMax = Math.max(this.dataMax, o.maxColorValue))),
                s || U.prototype.applyExtremes.call(o);
            }
          }
          drawCrosshair(t, e) {
            let i,
              s = this.legendItem || {},
              o = e?.plotX,
              r = e?.plotY,
              a = this.pos,
              n = this.len;
            e &&
              ((i = this.toPixels(e.getNestedProperty(e.series.colorKey))) < a
                ? (i = a - 2)
                : i > a + n && (i = a + n + 2),
              (e.plotX = i),
              (e.plotY = this.len - i),
              super.drawCrosshair(t, e),
              (e.plotX = o),
              (e.plotY = r),
              this.cross &&
                !this.cross.addedToColorAxis &&
                s.group &&
                (this.cross
                  .addClass("highcharts-coloraxis-marker")
                  .add(s.group),
                (this.cross.addedToColorAxis = !0),
                this.chart.styledMode ||
                  "object" != typeof this.crosshair ||
                  this.cross.attr({ fill: this.crosshair.color })));
          }
          getPlotLinePath(t) {
            let e = this.left,
              i = t.translatedValue,
              s = this.top;
            return q(i)
              ? this.horiz
                ? [["M", i - 4, s - 6], ["L", i + 4, s - 6], ["L", i, s], ["Z"]]
                : [["M", e, i], ["L", e - 6, i + 6], ["L", e - 6, i - 6], ["Z"]]
              : super.getPlotLinePath(t);
          }
          update(t, e) {
            let i = this.chart.legend;
            this.series.forEach((t) => {
              t.isDirtyData = !0;
            }),
              ((t.dataClasses && i.allItems) || this.dataClasses) &&
                this.destroyItems(),
              super.update(t, e),
              this.legendItem?.label &&
                (this.setLegendColor(), i.colorizeItem(this, !0));
          }
          destroyItems() {
            let t = this.chart,
              e = this.legendItem || {};
            if (e.label) t.legend.destroyItem(this);
            else if (e.labels) for (let i of e.labels) t.legend.destroyItem(i);
            t.isDirtyLegend = !0;
          }
          destroy() {
            (this.chart.isDirtyLegend = !0),
              this.destroyItems(),
              super.destroy(...[].slice.call(arguments));
          }
          remove(t) {
            this.destroyItems(), super.remove(t);
          }
          getDataClassLegendSymbols() {
            let t,
              e = this,
              i = e.chart,
              s = (e.legendItem && e.legendItem.labels) || [],
              o = i.options.legend,
              r = J(o.valueDecimals, -1),
              a = J(o.valueSuffix, ""),
              n = (t) =>
                e.series.reduce(
                  (e, i) => (
                    e.push(...i.points.filter((e) => e.dataClass === t)), e
                  ),
                  []
                );
            return (
              s.length ||
                e.dataClasses.forEach((o, l) => {
                  let h = o.from,
                    p = o.to,
                    { numberFormatter: d } = i,
                    c = !0;
                  (t = ""),
                    void 0 === h ? (t = "< ") : void 0 === p && (t = "> "),
                    void 0 !== h && (t += d(h, r) + a),
                    void 0 !== h && void 0 !== p && (t += " - "),
                    void 0 !== p && (t += d(p, r) + a),
                    s.push(
                      Z(
                        {
                          chart: i,
                          name: t,
                          options: {},
                          drawLegendSymbol: R().rectangle,
                          visible: !0,
                          isDataClass: !0,
                          setState: (t) => {
                            for (let e of n(l)) e.setState(t);
                          },
                          setVisible: function () {
                            this.visible = c = e.visible = !c;
                            let t = [];
                            for (let e of n(l))
                              e.setVisible(c),
                                (e.hiddenInDataClass = !c),
                                -1 === t.indexOf(e.series) && t.push(e.series);
                            i.legend.colorizeItem(this, c),
                              t.forEach((t) => {
                                _(t, "afterDataClassLegendClick");
                              });
                          },
                        },
                        o
                      )
                    );
                }),
              s
            );
          }
          getSize() {
            let { chart: t, horiz: e } = this,
              { height: i, width: s } = this.options,
              { legend: o } = t.options;
            return {
              width: J(
                F(s) ? Q(s, t.chartWidth) : void 0,
                o?.symbolWidth,
                e ? tt.defaultLegendLength : 12
              ),
              height: J(
                F(i) ? Q(i, t.chartHeight) : void 0,
                o?.symbolHeight,
                e ? 12 : tt.defaultLegendLength
              ),
            };
          }
        }
        (tt.defaultLegendLength = 200),
          (tt.keepProps = ["legendItem"]),
          Z(tt.prototype, G),
          Array.prototype.push.apply(A().keepProps, tt.keepProps);
        let te = L();
        (te.ColorAxis = te.ColorAxis || tt),
          te.ColorAxis.compose(te.Chart, te.Fx, te.Legend, te.Series);
        let ti = {
            lang: { zoomIn: "Zoom in", zoomOut: "Zoom out" },
            mapNavigation: {
              buttonOptions: {
                alignTo: "plotBox",
                align: "left",
                verticalAlign: "top",
                x: 0,
                width: 18,
                height: 18,
                padding: 5,
                style: {
                  color: "#666666",
                  fontSize: "1em",
                  fontWeight: "bold",
                },
                theme: {
                  fill: "#ffffff",
                  stroke: "#e6e6e6",
                  "stroke-width": 1,
                  "text-align": "center",
                },
              },
              buttons: {
                zoomIn: {
                  onclick: function () {
                    this.mapZoom(0.5);
                  },
                  text: "+",
                  y: 0,
                },
                zoomOut: {
                  onclick: function () {
                    this.mapZoom(2);
                  },
                  text: "-",
                  y: 28,
                },
              },
              mouseWheelSensitivity: 1.1,
            },
          },
          { defined: ts, extend: to, pick: tr, wrap: ta } = L();
        !(function (t) {
          let e,
            i = 0;
          function s(t) {
            let e = this.chart;
            (t = this.normalize(t)),
              e.options.mapNavigation.enableDoubleClickZoomTo
                ? e.pointer.inClass(t.target, "highcharts-tracker") &&
                  e.hoverPoint &&
                  e.hoverPoint.zoomTo()
                : e.isInsidePlot(t.chartX - e.plotLeft, t.chartY - e.plotTop) &&
                  e.mapZoom(0.5, void 0, void 0, t.chartX, t.chartY);
          }
          function o(t) {
            let s = this.chart,
              o =
                (ts((t = this.normalize(t)).wheelDelta) &&
                  -t.wheelDelta / 120) ||
                t.deltaY ||
                t.detail;
            Math.abs(o) >= 1 &&
              ((i += Math.abs(o)),
              e && clearTimeout(e),
              (e = setTimeout(() => {
                i = 0;
              }, 50))),
              i < 10 &&
                s.isInsidePlot(t.chartX - s.plotLeft, t.chartY - s.plotTop) &&
                s.mapView &&
                s.mapView.zoomBy(
                  -((s.options.mapNavigation.mouseWheelSensitivity - 1) * o),
                  void 0,
                  [t.chartX, t.chartY],
                  !(1 > Math.abs(o)) && void 0
                );
          }
          function r(t, e, i) {
            let s = this.chart;
            if (((e = t.call(this, e, i)), s && s.mapView)) {
              let t = s.mapView.pixelsToLonLat({
                x: e.chartX - s.plotLeft,
                y: e.chartY - s.plotTop,
              });
              t && to(e, t);
            }
            return e;
          }
          function a(t) {
            let e = this.chart.options.mapNavigation;
            e &&
              tr(e.enableTouchZoom, e.enabled) &&
              (this.chart.zooming.pinchType = "xy"),
              t.apply(this, [].slice.call(arguments, 1));
          }
          t.compose = function (t) {
            let e = t.prototype;
            e.onContainerDblClick ||
              (to(e, { onContainerDblClick: s, onContainerMouseWheel: o }),
              ta(e, "normalize", r),
              ta(e, "zoomOption", a));
          };
        })(g || (g = {}));
        let tn = g;
        function tl(t, e, i, s, o) {
          if (o) {
            let t = o?.r || 0;
            (o.brBoxY = e - t), (o.brBoxHeight = s + t);
          }
          return c.roundedRect(t, e, i, s, o);
        }
        function th(t, e, i, s, o) {
          if (o) {
            let t = o?.r || 0;
            o.brBoxHeight = s + t;
          }
          return c.roundedRect(t, e, i, s, o);
        }
        let tp = {
            compose: function (t) {
              ((c = t.prototype.symbols).bottombutton = tl), (c.topbutton = th);
            },
          },
          { setOptions: td } = L(),
          { composed: tc } = L(),
          {
            addEvent: tu,
            extend: tm,
            merge: tg,
            objectEach: tf,
            pick: tb,
            pushUnique: ty,
          } = L();
        function tx(t) {
          t &&
            (t.preventDefault?.(),
            t.stopPropagation?.(),
            (t.cancelBubble = !0));
        }
        class tM {
          static compose(t, e, i) {
            tn.compose(e),
              tp.compose(i),
              ty(tc, "Map.Navigation") &&
                (tu(t, "beforeRender", function () {
                  (this.mapNavigation = new tM(this)),
                    this.mapNavigation.update();
                }),
                td(ti));
          }
          constructor(t) {
            (this.chart = t), (this.navButtons = []);
          }
          update(t) {
            let e = this,
              i = e.chart,
              s = e.navButtons,
              o = function (t) {
                this.handler.call(i, t), tx(t);
              },
              r = i.options.mapNavigation;
            for (
              t &&
              (r = i.options.mapNavigation = tg(i.options.mapNavigation, t));
              s.length;

            )
              s.pop()?.destroy();
            if (!i.renderer.forExport && tb(r.enableButtons, r.enabled)) {
              e.navButtonsGroup ||
                (e.navButtonsGroup = i.renderer.g().attr({ zIndex: 7 }).add()),
                tf(r.buttons, (t, a) => {
                  let n = { padding: (t = tg(r.buttonOptions, t)).padding };
                  !i.styledMode &&
                    t.theme &&
                    (tm(n, t.theme), (n.style = tg(t.theme.style, t.style)));
                  let {
                      text: l,
                      width: h = 0,
                      height: p = 0,
                      padding: d = 0,
                    } = t,
                    c = i.renderer
                      .button(
                        ("+" !== l && "-" !== l && l) || "",
                        0,
                        0,
                        o,
                        n,
                        void 0,
                        void 0,
                        void 0,
                        "zoomIn" === a ? "topbutton" : "bottombutton"
                      )
                      .addClass(
                        "highcharts-map-navigation highcharts-" +
                          { zoomIn: "zoom-in", zoomOut: "zoom-out" }[a]
                      )
                      .attr({
                        width: h,
                        height: p,
                        title: i.options.lang[a],
                        zIndex: 5,
                      })
                      .add(e.navButtonsGroup);
                  if ("+" === l || "-" === l) {
                    let e = h + 1,
                      s = [
                        ["M", d + 3, d + p / 2],
                        ["L", d + e - 3, d + p / 2],
                      ];
                    "+" === l &&
                      s.push(
                        ["M", d + e / 2, d + 3],
                        ["L", d + e / 2, d + p - 3]
                      ),
                      i.renderer
                        .path(s)
                        .addClass("highcharts-button-symbol")
                        .attr(
                          i.styledMode
                            ? {}
                            : {
                                stroke: t.style?.color,
                                "stroke-width": 3,
                                "stroke-linecap": "round",
                              }
                        )
                        .add(c);
                  }
                  if (
                    ((c.handler = t.onclick),
                    tu(c.element, "dblclick", tx),
                    s.push(c),
                    tm(t, { width: c.width, height: 2 * (c.height || 0) }),
                    i.hasLoaded)
                  )
                    c.align(t, !1, t.alignTo);
                  else {
                    let e = tu(i, "load", () => {
                      c.element && c.align(t, !1, t.alignTo), e();
                    });
                  }
                });
              let t = (t, e) =>
                !(
                  e.x >= t.x + t.width ||
                  e.x + e.width <= t.x ||
                  e.y >= t.y + t.height ||
                  e.y + e.height <= t.y
                );
              i.hasLoaded ||
                tu(i, "render", function () {
                  let s = i.exporting?.group?.getBBox();
                  if (s) {
                    let i = e.navButtonsGroup.getBBox();
                    if (t(s, i)) {
                      let t = -i.y - i.height + s.y - 5,
                        o = s.y + s.height - i.y + 5,
                        a = r.buttonOptions && r.buttonOptions.verticalAlign;
                      e.navButtonsGroup.attr({
                        translateY: "bottom" === a ? t : o,
                      });
                    }
                  }
                });
            }
            this.updateEvents(r);
          }
          updateEvents(t) {
            let e = this.chart;
            tb(t.enableDoubleClickZoom, t.enabled) || t.enableDoubleClickZoomTo
              ? (this.unbindDblClick =
                  this.unbindDblClick ||
                  tu(e.container, "dblclick", function (t) {
                    e.pointer.onContainerDblClick(t);
                  }))
              : this.unbindDblClick &&
                (this.unbindDblClick = this.unbindDblClick()),
              tb(t.enableMouseWheelZoom, t.enabled)
                ? (this.unbindMouseWheel =
                    this.unbindMouseWheel ||
                    tu(e.container, "wheel", function (t) {
                      if (
                        !e.pointer.inClass(t.target, "highcharts-no-mousewheel")
                      ) {
                        let i = e.mapView?.zoom;
                        e.pointer.onContainerMouseWheel(t),
                          i !== e.mapView?.zoom && tx(t);
                      }
                      return !1;
                    }))
                : this.unbindMouseWheel &&
                  (this.unbindMouseWheel = this.unbindMouseWheel());
          }
        }
        var tv = w(28),
          tw = w.n(tv);
        let {
            column: { prototype: tC },
          } = W().seriesTypes,
          { addEvent: tT, defined: tL } = L();
        !(function (t) {
          function e(t) {
            let e = this.series,
              i = e.chart.renderer;
            this.moveToTopOnHover &&
              this.graphic &&
              (e.stateMarkerGraphic ||
                (e.stateMarkerGraphic = new (tw())(i, "use")
                  .css({ pointerEvents: "none" })
                  .add(this.graphic.parentGroup)),
              t?.state === "hover"
                ? (this.graphic.attr({ id: this.id }),
                  e.stateMarkerGraphic.attr({
                    href: `${i.url}#${this.id}`,
                    visibility: "visible",
                  }))
                : e.stateMarkerGraphic.attr({ href: "" }));
          }
          (t.pointMembers = {
            dataLabelOnNull: !0,
            moveToTopOnHover: !0,
            isValid: function () {
              return (
                null !== this.value &&
                this.value !== 1 / 0 &&
                this.value !== -1 / 0 &&
                (void 0 === this.value || !isNaN(this.value))
              );
            },
          }),
            (t.seriesMembers = {
              colorKey: "value",
              axisTypes: ["xAxis", "yAxis", "colorAxis"],
              parallelArrays: ["x", "y", "value"],
              pointArrayMap: ["value"],
              trackerGroups: ["group", "markerGroup", "dataLabelsGroup"],
              colorAttribs: function (t) {
                let e = {};
                return (
                  tL(t.color) &&
                    (!t.state || "normal" === t.state) &&
                    (e[this.colorProp || "fill"] = t.color),
                  e
                );
              },
              pointAttribs: tC.pointAttribs,
            }),
            (t.compose = function (t) {
              return tT(t.prototype.pointClass, "afterSetState", e), t;
            });
        })(f || (f = {}));
        let tP = f;
        var tA = w(820),
          tk = w.n(tA);
        let { deg2rad: tj } = L(),
          { fireEvent: tz, isNumber: tS, pick: tI, relativeLength: tB } = L();
        !(function (t) {
          (t.getCenter = function () {
            let t = this.options,
              e = this.chart,
              i = 2 * (t.slicedOffset || 0),
              s = e.plotWidth - 2 * i,
              o = e.plotHeight - 2 * i,
              r = t.center,
              a = Math.min(s, o),
              n = t.thickness,
              l,
              h = t.size,
              p = t.innerSize || 0,
              d,
              c;
            "string" == typeof h && (h = parseFloat(h)),
              "string" == typeof p && (p = parseFloat(p));
            let u = [
              tI(r?.[0], "50%"),
              tI(r?.[1], "50%"),
              tI(h && h < 0 ? void 0 : t.size, "100%"),
              tI(p && p < 0 ? void 0 : t.innerSize || 0, "0%"),
            ];
            for (
              !e.angular || this instanceof tk() || (u[3] = 0), d = 0;
              d < 4;
              ++d
            )
              (c = u[d]),
                (l = d < 2 || (2 === d && /%$/.test(c))),
                (u[d] = tB(c, [s, o, a, u[2]][d]) + (l ? i : 0));
            return (
              u[3] > u[2] && (u[3] = u[2]),
              tS(n) && 2 * n < u[2] && n > 0 && (u[3] = u[2] - 2 * n),
              tz(this, "afterGetCenter", { positions: u }),
              u
            );
          }),
            (t.getStartAndEndRadians = function (t, e) {
              let i = tS(t) ? t : 0,
                s = tS(e) && e > i && e - i < 360 ? e : i + 360;
              return { start: tj * (i + -90), end: tj * (s + -90) };
            });
        })(b || (b = {}));
        let tE = b;
        var tD = w(960),
          tV = w.n(tD),
          tO = w(540),
          tN = w.n(tO);
        let { getOptions: tG } = L(),
          { isNumber: tX, merge: tR, pick: tH } = L();
        class tW extends tV() {
          init(t, e) {
            let i = tG().credits,
              s = tR(
                {
                  chart: { panning: { enabled: !0, type: "xy" }, type: "map" },
                  credits: {
                    mapText: tH(
                      i.mapText,
                      ' \xa9 <a href="{geojson.copyrightUrl}">{geojson.copyrightShort}</a>'
                    ),
                    mapTextFull: tH(i.mapTextFull, "{geojson.copyright}"),
                  },
                  mapView: {},
                  tooltip: { followTouchMove: !1 },
                },
                t
              );
            super.init(s, e);
          }
          mapZoom(t, e, i, s, o) {
            this.mapView &&
              (tX(t) && (t = Math.log(t) / Math.log(0.5)),
              this.mapView.zoomBy(
                t,
                tX(e) && tX(i)
                  ? this.mapView.projection.inverse([e, i])
                  : void 0,
                tX(s) && tX(o) ? [s, o] : void 0
              ));
          }
          update(t) {
            t.chart &&
              "map" in t.chart &&
              this.mapView?.recommendMapView(
                this,
                [
                  t.chart.map,
                  ...(this.options.series || []).map((t) => t.mapData),
                ],
                !0
              ),
              super.update.apply(this, arguments);
          }
        }
        !(function (t) {
          (t.maps = {}),
            (t.mapChart = function (e, i, s) {
              return new t(e, i, s);
            }),
            (t.splitPath = function (t) {
              let e;
              return (
                (e =
                  "string" == typeof t
                    ? (t = t
                        .replace(/([A-Z])/gi, " $1 ")
                        .replace(/^\s*/, "")
                        .replace(/\s*$/, ""))
                        .split(/[ ,;]+/)
                        .map((t) => (/[A-Z]/i.test(t) ? t : parseFloat(t)))
                    : t),
                tN().prototype.pathToSegments(e)
              );
            });
        })(tW || (tW = {}));
        let tY = tW,
          tU = {
            boundsFromPath: function (t) {
              let e = -Number.MAX_VALUE,
                i = Number.MAX_VALUE,
                s = -Number.MAX_VALUE,
                o = Number.MAX_VALUE,
                r;
              if (
                (t.forEach((t) => {
                  let a = t[t.length - 2],
                    n = t[t.length - 1];
                  "number" == typeof a &&
                    "number" == typeof n &&
                    ((i = Math.min(i, a)),
                    (e = Math.max(e, a)),
                    (o = Math.min(o, n)),
                    (s = Math.max(s, n)),
                    (r = !0));
                }),
                r)
              )
                return { x1: i, y1: o, x2: e, y2: s };
            },
          },
          { boundsFromPath: tF } = tU,
          tZ = W().seriesTypes.scatter.prototype.pointClass,
          { extend: t_, isNumber: tK, pick: tq } = L();
        class t$ extends tZ {
          static getProjectedPath(t, e) {
            return (
              t.projectedPath ||
                (e && t.geometry
                  ? ((e.hasCoordinates = !0),
                    (t.projectedPath = e.path(t.geometry)))
                  : (t.projectedPath = t.path)),
              t.projectedPath || []
            );
          }
          applyOptions(t, e) {
            let i = this.series,
              s = super.applyOptions(t, e),
              o = i.joinBy;
            if (i.mapData && i.mapMap) {
              let t = o[1],
                e = super.getNestedProperty(t),
                r = void 0 !== e && i.mapMap[e];
              r
                ? t_(s, { ...r, name: s.name ?? r.name })
                : -1 !== i.pointArrayMap.indexOf("value") &&
                  (s.value = s.value || null);
            }
            return s;
          }
          getProjectedBounds(t) {
            let e = tF(t$.getProjectedPath(this, t)),
              i = this.properties,
              s = this.series.chart.mapView;
            if (e) {
              let o = i?.["hc-middle-lon"],
                r = i?.["hc-middle-lat"];
              if (s && tK(o) && tK(r)) {
                let i = t.forward([o, r]);
                (e.midX = i[0]), (e.midY = i[1]);
              } else {
                let t = i?.["hc-middle-x"],
                  s = i?.["hc-middle-y"];
                e.midX =
                  e.x1 + (e.x2 - e.x1) * tq(this.middleX, tK(t) ? t : 0.5);
                let o = tq(this.middleY, tK(s) ? s : 0.5);
                this.geometry || (o = 1 - o),
                  (e.midY = e.y2 - (e.y2 - e.y1) * o);
              }
              return e;
            }
          }
          onMouseOver(t) {
            L().clearTimeout(this.colorInterval),
              (!this.isNull && this.visible) ||
              this.series.options.nullInteraction
                ? super.onMouseOver.call(this, t)
                : this.series.onMouseOut();
          }
          setVisible(t) {
            (this.visible = this.options.visible = !!t),
              this.dataLabel && this.dataLabel[t ? "show" : "hide"](),
              this.graphic && this.graphic.attr(this.series.pointAttribs(this));
          }
          zoomTo(t) {
            let e = this.series.chart,
              i = e.mapView,
              s = this.bounds;
            if (i && s) {
              let o = tK(this.insetIndex) && i.insets[this.insetIndex];
              if (o) {
                let t = o.projectedUnitsToPixels({ x: s.x1, y: s.y1 }),
                  e = o.projectedUnitsToPixels({ x: s.x2, y: s.y2 }),
                  r = i.pixelsToProjectedUnits({ x: t.x, y: t.y }),
                  a = i.pixelsToProjectedUnits({ x: e.x, y: e.y });
                s = { x1: r.x, y1: r.y, x2: a.x, y2: a.y };
              }
              i.fitToBounds(s, void 0, !1),
                (this.series.isDirty = !0),
                e.redraw(t);
            }
          }
        }
        t_(t$.prototype, {
          dataLabelOnNull: tP.pointMembers.dataLabelOnNull,
          moveToTopOnHover: tP.pointMembers.moveToTopOnHover,
          isValid: tP.pointMembers.isValid,
        });
        let { isNumber: tJ } = L(),
          tQ = {
            center: [0, 0],
            fitToGeometry: void 0,
            maxZoom: void 0,
            padding: 0,
            projection: { name: void 0, parallels: void 0, rotation: void 0 },
            zoom: void 0,
            insetOptions: {
              borderColor: "#cccccc",
              borderWidth: 1,
              padding: "10%",
              relativeTo: "mapBoundingBox",
              units: "percent",
            },
          };
        var t0 = w(984),
          t1 = w.n(t0);
        let { win: t2 } = L(),
          { format: t6 } = t1(),
          { error: t3, extend: t8, merge: t7, wrap: t9 } = L();
        !(function (t) {
          function e(t) {
            return this.mapView && this.mapView.lonLatToProjectedUnits(t);
          }
          function i(t) {
            return this.mapView && this.mapView.projectedUnitsToLonLat(t);
          }
          function s(t, e) {
            let i = this.options.chart.proj4 || t2.proj4;
            if (!i) return void t3(21, !1, this);
            let {
                jsonmarginX: s = 0,
                jsonmarginY: o = 0,
                jsonres: r = 1,
                scale: a = 1,
                xoffset: n = 0,
                xpan: l = 0,
                yoffset: h = 0,
                ypan: p = 0,
              } = e,
              d = i(e.crs, [t.lon, t.lat]),
              c = e.cosAngle || (e.rotation && Math.cos(e.rotation)),
              u = e.sinAngle || (e.rotation && Math.sin(e.rotation)),
              m = e.rotation ? [d[0] * c + d[1] * u, -d[0] * u + d[1] * c] : d;
            return {
              x: ((m[0] - n) * a + l) * r + s,
              y: -(((h - m[1]) * a + p) * r - o),
            };
          }
          function o(t, e) {
            let i = this.options.chart.proj4 || t2.proj4;
            if (!i) return void t3(21, !1, this);
            if (null === t.y) return;
            let {
                jsonmarginX: s = 0,
                jsonmarginY: o = 0,
                jsonres: r = 1,
                scale: a = 1,
                xoffset: n = 0,
                xpan: l = 0,
                yoffset: h = 0,
                ypan: p = 0,
              } = e,
              d = {
                x: ((t.x - s) / r - l) / a + n,
                y: ((t.y - o) / r + p) / a + h,
              },
              c = e.cosAngle || (e.rotation && Math.cos(e.rotation)),
              u = e.sinAngle || (e.rotation && Math.sin(e.rotation)),
              m = i(
                e.crs,
                "WGS84",
                e.rotation
                  ? { x: d.x * c + -(d.y * u), y: d.x * u + d.y * c }
                  : d
              );
            return { lat: m.y, lon: m.x };
          }
          function r(t, e) {
            e || (e = Object.keys(t.objects)[0]);
            let i = t.objects[e];
            if (
              i["hc-decoded-geojson"] &&
              i["hc-decoded-geojson"].title === t.title
            )
              return i["hc-decoded-geojson"];
            let s = t.arcs;
            if (t.transform) {
              let e,
                i,
                o,
                r = t.arcs,
                { scale: a, translate: n } = t.transform;
              s = [];
              for (let t = 0, l = r.length; t < l; ++t) {
                let l = r[t];
                s.push((e = [])), (i = 0), (o = 0);
                for (let t = 0, s = l.length; t < s; ++t)
                  e.push([
                    (i += l[t][0]) * a[0] + n[0],
                    (o += l[t][1]) * a[1] + n[1],
                  ]);
              }
            }
            let o = (t) =>
                "number" == typeof t[0]
                  ? t.reduce((t, e, i) => {
                      let o = e < 0 ? s[~e] : s[e];
                      return (
                        e < 0
                          ? (o = o.slice(
                              0,
                              0 === i ? o.length : o.length - 1
                            )).reverse()
                          : i && (o = o.slice(1)),
                        t.concat(o)
                      );
                    }, [])
                  : t.map(o),
              r = i.geometries,
              a = [];
            for (let t = 0, e = r.length; t < e; ++t)
              a.push({
                type: "Feature",
                properties: r[t].properties,
                geometry: {
                  type: r[t].type,
                  coordinates: r[t].coordinates || o(r[t].arcs),
                },
              });
            let n = {
              type: "FeatureCollection",
              copyright: t.copyright,
              copyrightShort: t.copyrightShort,
              copyrightUrl: t.copyrightUrl,
              features: a,
              "hc-recommended-mapview": i["hc-recommended-mapview"],
              bbox: t.bbox,
              title: t.title,
            };
            return (i["hc-decoded-geojson"] = n), n;
          }
          function a(t, e) {
            (e = t7(!0, this.options.credits, e)),
              t.call(this, e),
              this.credits &&
                this.mapCreditsFull &&
                this.credits.attr({ title: this.mapCreditsFull });
          }
          (t.compose = function (t) {
            let r = t.prototype;
            r.transformFromLatLon ||
              ((r.fromLatLonToPoint = e),
              (r.fromPointToLatLon = i),
              (r.transformFromLatLon = s),
              (r.transformToLatLon = o),
              t9(r, "addCredits", a));
          }),
            (t.geojson = function (t, e = "map", i) {
              let s = [],
                o = "Topology" === t.type ? r(t) : t,
                a = o.features;
              for (let t = 0, i = a.length; t < i; ++t) {
                let i,
                  o = a[t],
                  r = o.geometry || {},
                  n = r.type,
                  l = r.coordinates,
                  h = o.properties;
                if (
                  ((("map" === e || "mapbubble" === e) &&
                    ("Polygon" === n || "MultiPolygon" === n)) ||
                  ("mapline" === e &&
                    ("LineString" === n || "MultiLineString" === n))
                    ? l.length &&
                      (i = { geometry: { coordinates: l, type: n } })
                    : "mappoint" === e &&
                      "Point" === n &&
                      l.length &&
                      (i = { geometry: { coordinates: l, type: n } }),
                  i)
                ) {
                  let t = h && (h.name || h.NAME),
                    e = h && h.lon,
                    o = h && h.lat;
                  s.push(
                    t8(i, {
                      lat: "number" == typeof o ? o : void 0,
                      lon: "number" == typeof e ? e : void 0,
                      name: "string" == typeof t ? t : void 0,
                      properties: h,
                    })
                  );
                }
              }
              return (
                i &&
                  o.copyrightShort &&
                  ((i.chart.mapCredits = t6(i.chart.options.credits?.mapText, {
                    geojson: o,
                  })),
                  (i.chart.mapCreditsFull = t6(
                    i.chart.options.credits?.mapTextFull,
                    { geojson: o }
                  ))),
                s
              );
            }),
            (t.topo2geo = r);
        })(y || (y = {}));
        let t4 = y;
        !(function (t) {
          (t.getCenterOfPoints = function (t) {
            let e = t.reduce((t, e) => ((t.x += e.x), (t.y += e.y), t), {
              x: 0,
              y: 0,
            });
            return { x: e.x / t.length, y: e.y / t.length };
          }),
            (t.getDistanceBetweenPoints = function (t, e) {
              return Math.sqrt(Math.pow(e.x - t.x, 2) + Math.pow(e.y - t.y, 2));
            }),
            (t.getAngleBetweenPoints = function (t, e) {
              return Math.atan2(e.x - t.x, e.y - t.y);
            }),
            (t.pointInPolygon = function ({ x: t, y: e }, i) {
              let s = i.length,
                o,
                r,
                a = !1;
              for (o = 0, r = s - 1; o < s; r = o++) {
                let [s, n] = i[o],
                  [l, h] = i[r];
                n > e != h > e &&
                  t < ((l - s) * (e - n)) / (h - n) + s &&
                  (a = !a);
              }
              return a;
            });
        })(x || (x = {}));
        let t5 = x;
        function et(t, e, i = !0) {
          let s = e[e.length - 1],
            o,
            r,
            a,
            n = t;
          for (let t = 0; t < e.length; t++) {
            let l = n;
            (o = e[t]), (n = []), (r = i ? l[l.length - 1] : l[0]);
            for (let t = 0; t < l.length; t++)
              ee(s, o, (a = l[t]))
                ? (ee(s, o, r) || n.push(ei(s, o, r, a)), n.push(a))
                : ee(s, o, r) && n.push(ei(s, o, r, a)),
                (r = a);
            s = o;
          }
          return n;
        }
        function ee(t, e, i) {
          return (e[0] - t[0]) * (i[1] - t[1]) > (e[1] - t[1]) * (i[0] - t[0]);
        }
        function ei(t, e, i, s) {
          let o = [t[0] - e[0], t[1] - e[1]],
            r = [i[0] - s[0], i[1] - s[1]],
            a = t[0] * e[1] - t[1] * e[0],
            n = i[0] * s[1] - i[1] * s[0],
            l = 1 / (o[0] * r[1] - o[1] * r[0]),
            h = [(a * r[0] - n * o[0]) * l, (a * r[1] - n * o[1]) * l];
          return (h.isIntersection = !0), h;
        }
        let es = Math.sign || ((t) => (0 === t ? 0 : t > 0 ? 1 : -1)),
          eo = Math.PI / 180,
          er = Math.PI / 2,
          ea = (t) => Math.tan((er + t) / 2),
          en = class {
            constructor(t) {
              let e = (t.parallels || []).map((t) => t * eo),
                i = e[0] || 0,
                s = e[1] ?? i,
                o = Math.cos(i);
              "object" == typeof t.projectedBounds &&
                (this.projectedBounds = t.projectedBounds);
              let r =
                i === s
                  ? Math.sin(i)
                  : Math.log(o / Math.cos(s)) / Math.log(ea(s) / ea(i));
              1e-10 > Math.abs(r) && (r = 1e-10 * (es(r) || 1)),
                (this.n = r),
                (this.c = (o * Math.pow(ea(i), r)) / r);
            }
            forward(t) {
              let { c: e, n: i, projectedBounds: s } = this,
                o = t[0] * eo,
                r = t[1] * eo;
              e > 0
                ? r < -er + 1e-6 && (r = -er + 1e-6)
                : r > er - 1e-6 && (r = er - 1e-6);
              let a = e / Math.pow(ea(r), i),
                n = a * Math.sin(i * o) * 63.78137,
                l = (e - a * Math.cos(i * o)) * 63.78137,
                h = [n, l];
              return (
                s &&
                  (n < s.x1 || n > s.x2 || l < s.y1 || l > s.y2) &&
                  (h.outside = !0),
                h
              );
            }
            inverse(t) {
              let { c: e, n: i } = this,
                s = t[0] / 63.78137,
                o = e - t[1] / 63.78137,
                r = es(i) * Math.sqrt(s * s + o * o),
                a = Math.atan2(s, Math.abs(o)) * es(o);
              return (
                o * i < 0 && (a -= Math.PI * es(s) * es(o)),
                [a / i / eo, (2 * Math.atan(Math.pow(e / r, 1 / i)) - er) / eo]
              );
            }
          },
          el = Math.sqrt(3) / 2,
          eh = class {
            constructor() {
              this.bounds = {
                x1: -200.37508342789243,
                x2: 200.37508342789243,
                y1: -97.52595454902263,
                y2: 97.52595454902263,
              };
            }
            forward(t) {
              let e = Math.PI / 180,
                i = Math.asin(el * Math.sin(t[1] * e)),
                s = i * i,
                o = s * s * s;
              return [
                (t[0] * e * Math.cos(i) * 74.03120656864502) /
                  (el *
                    (1.340264 +
                      -0.24331799999999998 * s +
                      o * (0.0062510000000000005 + 0.034164 * s))),
                74.03120656864502 *
                  i *
                  (1.340264 + -0.081106 * s + o * (893e-6 + 0.003796 * s)),
              ];
            }
            inverse(t) {
              let e = t[0] / 74.03120656864502,
                i = t[1] / 74.03120656864502,
                s = 180 / Math.PI,
                o = i,
                r,
                a,
                n,
                l;
              for (
                let t = 0;
                t < 12 &&
                ((a = (r = o * o) * r * r),
                (n =
                  o * (1.340264 + -0.081106 * r + a * (893e-6 + 0.003796 * r)) -
                  i),
                (o -= l =
                  n /
                  (1.340264 +
                    -0.24331799999999998 * r +
                    a * (0.0062510000000000005 + 0.034164 * r))),
                !(1e-9 > Math.abs(l)));
                ++t
              );
              a = (r = o * o) * r * r;
              let h =
                  (s *
                    el *
                    e *
                    (1.340264 +
                      -0.24331799999999998 * r +
                      a * (0.0062510000000000005 + 0.034164 * r))) /
                  Math.cos(o),
                p = s * Math.asin(Math.sin(o) / el);
              return Math.abs(h) > 180 ? [NaN, NaN] : [h, p];
            }
          },
          ep = Math.PI / 4,
          ed = Math.PI / 180,
          ec = class {
            constructor() {
              this.bounds = {
                x1: -200.37508342789243,
                x2: 200.37508342789243,
                y1: -146.91480769173063,
                y2: 146.91480769173063,
              };
            }
            forward(t) {
              return [
                t[0] * ed * 63.78137,
                79.7267125 * Math.log(Math.tan(ep + 0.4 * t[1] * ed)),
              ];
            }
            inverse(t) {
              return [
                t[0] / 63.78137 / ed,
                (2.5 * (Math.atan(Math.exp(0.8 * (t[1] / 63.78137))) - ep)) /
                  ed,
              ];
            }
          },
          eu = Math.PI / 180,
          em = class {
            constructor() {
              (this.antimeridianCutting = !1),
                (this.bounds = {
                  x1: -63.78460826781007,
                  x2: 63.78460826781007,
                  y1: -63.78460826781007,
                  y2: 63.78460826781007,
                });
            }
            forward(t) {
              let e = t[0],
                i = t[1] * eu,
                s = [
                  Math.cos(i) * Math.sin(e * eu) * 63.78460826781007,
                  63.78460826781007 * Math.sin(i),
                ];
              return (e < -90 || e > 90) && (s.outside = !0), s;
            }
            inverse(t) {
              let e = t[0] / 63.78460826781007,
                i = t[1] / 63.78460826781007,
                s = Math.sqrt(e * e + i * i),
                o = Math.asin(s),
                r = Math.sin(o);
              return [
                Math.atan2(e * r, s * Math.cos(o)) / eu,
                Math.asin(s && (i * r) / s) / eu,
              ];
            }
          },
          eg = Math.PI / 180,
          ef = class {
            constructor() {
              (this.bounds = {
                x1: -200.37508342789243,
                x2: 200.37508342789243,
                y1: -200.3750834278071,
                y2: 200.3750834278071,
              }),
                (this.maxLatitude = 85.0511287798);
            }
            forward(t) {
              let e = Math.sin(t[1] * eg),
                i = [
                  63.78137 * t[0] * eg,
                  (63.78137 * Math.log((1 + e) / (1 - e))) / 2,
                ];
              return Math.abs(t[1]) > this.maxLatitude && (i.outside = !0), i;
            }
            inverse(t) {
              return [
                t[0] / (63.78137 * eg),
                (2 * Math.atan(Math.exp(t[1] / 63.78137)) - Math.PI / 2) / eg,
              ];
            }
          },
          { clipLineString: eb, clipPolygon: ey } = {
            clipLineString: function (t, e) {
              let i = [],
                s = et(t, e, !1);
              for (let t = 1; t < s.length; t++)
                s[t].isIntersection &&
                  s[t - 1].isIntersection &&
                  (i.push(s.splice(0, t)), (t = 0)),
                  t === s.length - 1 && i.push(s);
              return i;
            },
            clipPolygon: et,
          },
          { clamp: ex, erase: eM } = L(),
          ev = (2 * Math.PI) / 360,
          ew = (t) => (t < -180 && (t += 360), t > 180 && (t -= 360), t),
          eC = (t) => (1 - Math.cos(t)) / 2,
          eT = (t, e) => {
            let i = Math.cos,
              s = t[1] * ev,
              o = t[0] * ev,
              r = e[1] * ev,
              a = e[0] * ev;
            return eC(r - s) + i(s) * i(r) * eC(a - o);
          };
        class eL {
          static add(t, e) {
            eL.registry[t] = e;
          }
          static distance(t, e) {
            let { atan2: i, sqrt: s } = Math,
              o = eT(t, e);
            return 6371e3 * (2 * i(s(o), s(1 - o)));
          }
          static geodesic(t, e, i, s = 5e5) {
            let { atan2: o, cos: r, sin: a, sqrt: n } = Math,
              l = eL.distance,
              h = t[1] * ev,
              p = t[0] * ev,
              d = e[1] * ev,
              c = e[0] * ev,
              u = r(h) * r(p),
              m = r(d) * r(c),
              g = r(h) * a(p),
              f = r(d) * a(c),
              b = a(h),
              y = a(d),
              x = l(t, e),
              M = x / 6371e3,
              v = a(M),
              w = Math.round(x / s),
              C = [];
            if ((i && C.push(t), w > 1)) {
              let t = 1 / w;
              for (let e = t; e < 0.999; e += t) {
                let t = a((1 - e) * M) / v,
                  i = a(e * M) / v,
                  s = t * u + i * m,
                  r = t * g + i * f,
                  l = o(t * b + i * y, n(s * s + r * r)),
                  h = o(r, s);
                C.push([h / ev, l / ev]);
              }
            }
            return i && C.push(e), C;
          }
          static insertGeodesics(t) {
            let e = t.length - 1;
            for (; e--; )
              if (
                Math.max(
                  Math.abs(t[e][0] - t[e + 1][0]),
                  Math.abs(t[e][1] - t[e + 1][1])
                ) > 10
              ) {
                let i = eL.geodesic(t[e], t[e + 1]);
                i.length && t.splice(e + 1, 0, ...i);
              }
          }
          static toString(t) {
            let { name: e, rotation: i } = t || {};
            return [e, i && i.join(",")].join(";");
          }
          constructor(t = {}) {
            (this.hasCoordinates = !1),
              (this.hasGeoProjection = !1),
              (this.maxLatitude = 90),
              (this.options = t);
            let { name: e, projectedBounds: i, rotation: s } = t;
            this.rotator = s ? this.getRotator(s) : void 0;
            let o = e ? eL.registry[e] : void 0;
            o && (this.def = new o(t));
            let { def: r, rotator: a } = this;
            r &&
              ((this.maxLatitude = r.maxLatitude || 90),
              (this.hasGeoProjection = !0)),
              a && r
                ? ((this.forward = (t) => r.forward(a.forward(t))),
                  (this.inverse = (t) => a.inverse(r.inverse(t))))
                : r
                ? ((this.forward = (t) => r.forward(t)),
                  (this.inverse = (t) => r.inverse(t)))
                : a && ((this.forward = a.forward), (this.inverse = a.inverse)),
              (this.bounds = "world" === i ? r && r.bounds : i);
          }
          lineIntersectsBounds(t) {
            let { x1: e, x2: i, y1: s, y2: o } = this.bounds || {},
              r = (t, e, i) => {
                let [s, o] = t,
                  r = +!e;
                if ("number" == typeof i && s[e] >= i != o[e] >= i) {
                  let t = (i - s[e]) / (o[e] - s[e]),
                    a = s[r] + t * (o[r] - s[r]);
                  return e ? [a, i] : [i, a];
                }
              },
              a,
              n = t[0];
            return (
              (a = r(t, 0, e))
                ? ((n = a), (t[1] = a))
                : (a = r(t, 0, i)) && ((n = a), (t[1] = a)),
              (a = r(t, 1, s)) ? (n = a) : (a = r(t, 1, o)) && (n = a),
              n
            );
          }
          getRotator(t) {
            let e = t[0] * ev,
              i = (t[1] || 0) * ev,
              s = (t[2] || 0) * ev,
              o = Math.cos(i),
              r = Math.sin(i),
              a = Math.cos(s),
              n = Math.sin(s);
            if (0 !== e || 0 !== i || 0 !== s)
              return {
                forward: (t) => {
                  let i = t[0] * ev + e,
                    s = t[1] * ev,
                    l = Math.cos(s),
                    h = Math.cos(i) * l,
                    p = Math.sin(i) * l,
                    d = Math.sin(s),
                    c = d * o + h * r;
                  return [
                    Math.atan2(p * a - c * n, h * o - d * r) / ev,
                    Math.asin(c * a + p * n) / ev,
                  ];
                },
                inverse: (t) => {
                  let i = t[0] * ev,
                    s = t[1] * ev,
                    l = Math.cos(s),
                    h = Math.cos(i) * l,
                    p = Math.sin(i) * l,
                    d = Math.sin(s),
                    c = d * a - p * n;
                  return [
                    (Math.atan2(p * a + d * n, h * o + c * r) - e) / ev,
                    Math.asin(c * o - h * r) / ev,
                  ];
                },
              };
          }
          forward(t) {
            return t;
          }
          inverse(t) {
            return t;
          }
          cutOnAntimeridian(t, e) {
            let i,
              s = [],
              o = [t];
            for (let i = 0, o = t.length; i < o; ++i) {
              let o = t[i],
                r = t[i - 1];
              if (!i) {
                if (!e) continue;
                r = t[t.length - 1];
              }
              let a = r[0],
                n = o[0];
              if (
                (a < -90 || a > 90) &&
                (n < -90 || n > 90) &&
                a > 0 != n > 0
              ) {
                let t = ex(
                    (180 - ((a + 360) % 360)) /
                      (((n + 360) % 360) - ((a + 360) % 360)),
                    0,
                    1
                  ),
                  e = r[1] + t * (o[1] - r[1]);
                s.push({
                  i,
                  lat: e,
                  direction: a < 0 ? 1 : -1,
                  previousLonLat: r,
                  lonLat: o,
                });
              }
            }
            if (s.length)
              if (e) {
                s.length % 2 == 1 &&
                  ((i = s
                    .slice()
                    .sort((t, e) => Math.abs(e.lat) - Math.abs(t.lat))[0]),
                  eM(s, i));
                let e = s.length - 2;
                for (; e >= 0; ) {
                  let i = s[e].i,
                    r = ew(180 + 1e-6 * s[e].direction),
                    a = ew(180 - 1e-6 * s[e].direction),
                    n = t.splice(
                      i,
                      s[e + 1].i - i,
                      ...eL.geodesic([r, s[e].lat], [r, s[e + 1].lat], !0)
                    );
                  n.push(...eL.geodesic([a, s[e + 1].lat], [a, s[e].lat], !0)),
                    o.push(n),
                    (e -= 2);
                }
                if (i)
                  for (let t = 0; t < o.length; t++) {
                    let { direction: e, lat: s } = i,
                      r = o[t],
                      a = r.indexOf(i.lonLat);
                    if (a > -1) {
                      let t = (s < 0 ? -1 : 1) * this.maxLatitude,
                        o = ew(180 + 1e-6 * e),
                        n = ew(180 - 1e-6 * e),
                        l = eL.geodesic([o, s], [o, t], !0);
                      for (
                        let i = o + 120 * e;
                        i > -180 && i < 180;
                        i += 120 * e
                      )
                        l.push([i, t]);
                      l.push(...eL.geodesic([n, t], [n, i.lat], !0)),
                        r.splice(a, 0, ...l);
                      break;
                    }
                  }
              } else {
                let e = s.length;
                for (; e--; ) {
                  let i = s[e].i,
                    r = t.splice(i, t.length, [
                      ew(180 + 1e-6 * s[e].direction),
                      s[e].lat,
                    ]);
                  r.unshift([ew(180 - 1e-6 * s[e].direction), s[e].lat]),
                    o.push(r);
                }
              }
            return o;
          }
          path(t) {
            let e,
              { bounds: i, def: s, rotator: o } = this,
              r = [],
              a = "Polygon" === t.type || "MultiPolygon" === t.type,
              n = this.hasGeoProjection,
              l = !s || !1 !== s.antimeridianCutting,
              h = l ? o : void 0,
              p = (l && s) || this;
            i &&
              (e = [
                [i.x1, i.y1],
                [i.x2, i.y1],
                [i.x2, i.y2],
                [i.x1, i.y2],
              ]);
            let d = (t) => {
              let s = t.map((t) => {
                  if (l) {
                    h && (t = h.forward(t));
                    let e = t[0];
                    1e-6 > Math.abs(e - 180) &&
                      (e = e < 180 ? 179.999999 : 180.000001),
                      (t = [e, t[1]]);
                  }
                  return t;
                }),
                o = [s];
              n &&
                (eL.insertGeodesics(s),
                l && (o = this.cutOnAntimeridian(s, a))),
                o.forEach((t) => {
                  let s, o;
                  if (t.length < 2) return;
                  let h = !1,
                    d = !1,
                    c = (t) => {
                      h
                        ? r.push(["L", t[0], t[1]])
                        : (r.push(["M", t[0], t[1]]), (h = !0));
                    },
                    u = !1,
                    m = !1,
                    g = t.map((t) => {
                      let e = p.forward(t);
                      return (
                        e.outside ? (u = !0) : (m = !0),
                        e[1] === 1 / 0
                          ? (e[1] = 1e10)
                          : e[1] === -1 / 0 && (e[1] = -1e10),
                        e
                      );
                    });
                  if (l) {
                    if ((a && g.push(g[0]), u)) {
                      if (!m) return;
                      if (e) {
                        if (a) g = ey(g, e);
                        else if (i)
                          return void eb(g, e).forEach((t) => {
                            (h = !1), t.forEach(c);
                          });
                      }
                    }
                    g.forEach(c);
                  } else
                    for (let e = 0; e < g.length; e++) {
                      let i = t[e],
                        r = g[e];
                      r.outside
                        ? (d = !0)
                        : (a && !s && ((s = i), t.push(i), g.push(r)),
                          d &&
                            o &&
                            (a && n
                              ? eL
                                  .geodesic(o, i)
                                  .forEach((t) => c(p.forward(t)))
                              : (h = !1)),
                          c(r),
                          (o = i),
                          (d = !1));
                    }
                });
            };
            return (
              "LineString" === t.type
                ? d(t.coordinates)
                : "MultiLineString" === t.type
                ? t.coordinates.forEach((t) => d(t))
                : "Polygon" === t.type
                ? (t.coordinates.forEach((t) => d(t)),
                  r.length && r.push(["Z"]))
                : "MultiPolygon" === t.type &&
                  (t.coordinates.forEach((t) => {
                    t.forEach((t) => d(t));
                  }),
                  r.length && r.push(["Z"])),
              r
            );
          }
        }
        eL.registry = {
          EqualEarth: eh,
          LambertConformalConic: en,
          Miller: ec,
          Orthographic: em,
          WebMercator: ef,
        };
        let { composed: eP } = L(),
          { pointInPolygon: eA } = t5,
          { topo2geo: ek } = t4,
          { boundsFromPath: ej } = tU,
          {
            addEvent: ez,
            clamp: eS,
            crisp: eI,
            fireEvent: eB,
            isArray: eE,
            isNumber: eD,
            isObject: eV,
            isString: eO,
            merge: eN,
            pick: eG,
            pushUnique: eX,
            relativeLength: eR,
          } = L(),
          eH = {};
        function eW(t, e) {
          let { width: i, height: s } = e;
          return (
            Math.log(
              400.979322 /
                Math.max((t.x2 - t.x1) / (i / 256), (t.y2 - t.y1) / (s / 256))
            ) / Math.log(2)
          );
        }
        function eY(t) {
          t.seriesOptions.mapData &&
            this.mapView?.recommendMapView(
              this,
              [this.options.chart.map, t.seriesOptions.mapData],
              this.options.drilldown?.mapZooming
            );
        }
        class eU {
          static compose(t) {
            eX(eP, "MapView") &&
              ((eH = t.maps),
              ez(
                t,
                "afterInit",
                function () {
                  this.mapView = new eU(this, this.options.mapView);
                },
                { order: 0 }
              ),
              ez(t, "addSeriesAsDrilldown", eY),
              ez(t, "afterDrillUp", eY));
          }
          static compositeBounds(t) {
            if (t.length)
              return t
                .slice(1)
                .reduce(
                  (t, e) => (
                    (t.x1 = Math.min(t.x1, e.x1)),
                    (t.y1 = Math.min(t.y1, e.y1)),
                    (t.x2 = Math.max(t.x2, e.x2)),
                    (t.y2 = Math.max(t.y2, e.y2)),
                    t
                  ),
                  eN(t[0])
                );
          }
          static mergeInsets(t, e) {
            let i = (t) => {
                let e = {};
                return (
                  t.forEach((t, i) => {
                    e[(t && t.id) || `i${i}`] = t;
                  }),
                  e
                );
              },
              s = eN(i(t), i(e));
            return Object.keys(s).map((t) => s[t]);
          }
          constructor(t, e) {
            (this.allowTransformAnimation = !0),
              (this.eventsToUnbind = []),
              (this.insets = []),
              (this.padding = [0, 0, 0, 0]),
              (this.recommendedMapView = {}),
              this instanceof eF ||
                this.recommendMapView(t, [
                  t.options.chart.map,
                  ...(t.options.series || []).map((t) => t.mapData),
                ]),
              (this.userOptions = e || {});
            let i = eN(tQ, this.recommendedMapView, e),
              s = this.recommendedMapView?.insets,
              o = e && e.insets;
            s && o && (i.insets = eU.mergeInsets(s, o)),
              (this.chart = t),
              (this.center = i.center),
              (this.options = i),
              (this.projection = new eL(i.projection)),
              (this.playingField = t.plotBox),
              (this.zoom = i.zoom || 0),
              (this.minZoom = i.minZoom),
              this.createInsets(),
              this.eventsToUnbind.push(
                ez(t, "afterSetChartSize", () => {
                  (this.playingField = this.getField()),
                    (void 0 === this.minZoom || this.minZoom === this.zoom) &&
                      (this.fitToBounds(void 0, void 0, !1),
                      !this.chart.hasRendered &&
                        eD(this.userOptions.zoom) &&
                        (this.zoom = this.userOptions.zoom),
                      this.userOptions.center &&
                        eN(!0, this.center, this.userOptions.center));
                })
              ),
              this.setUpEvents();
          }
          createInsets() {
            let t = this.options,
              e = t.insets;
            e &&
              e.forEach((e) => {
                let i = new eF(this, eN(t.insetOptions, e));
                this.insets.push(i);
              });
          }
          fitToBounds(t, e, i = !0, s) {
            let o = t || this.getProjectedBounds();
            if (o) {
              let r = eG(e, t ? 0 : this.options.padding),
                a = this.getField(!1),
                n = eE(r) ? r : [r, r, r, r];
              (this.padding = [
                eR(n[0], a.height),
                eR(n[1], a.width),
                eR(n[2], a.height),
                eR(n[3], a.width),
              ]),
                (this.playingField = this.getField());
              let l = eW(o, this.playingField);
              t || (this.minZoom = l);
              let h = this.projection.inverse([
                (o.x2 + o.x1) / 2,
                (o.y2 + o.y1) / 2,
              ]);
              this.setView(h, l, i, s);
            }
          }
          getField(t = !0) {
            let e = t ? this.padding : [0, 0, 0, 0];
            return {
              x: e[3],
              y: e[0],
              width: this.chart.plotWidth - e[1] - e[3],
              height: this.chart.plotHeight - e[0] - e[2],
            };
          }
          getGeoMap(t) {
            if (eO(t))
              return eH[t] && "Topology" === eH[t].type ? ek(eH[t]) : eH[t];
            if (eV(t, !0)) {
              if ("FeatureCollection" === t.type) return t;
              if ("Topology" === t.type) return ek(t);
            }
          }
          getMapBBox() {
            let t = this.getProjectedBounds(),
              e = this.getScale();
            if (t) {
              let i = this.padding,
                s = this.projectedUnitsToPixels({ x: t.x1, y: t.y2 });
              return {
                width: (t.x2 - t.x1) * e + i[1] + i[3],
                height: (t.y2 - t.y1) * e + i[0] + i[2],
                x: s.x - i[3],
                y: s.y - i[0],
              };
            }
          }
          getProjectedBounds() {
            let t = this.projection,
              e = this.chart.series.reduce((t, e) => {
                let i = e.getProjectedBounds && e.getProjectedBounds();
                return i && !1 !== e.options.affectsMapView && t.push(i), t;
              }, []),
              i = this.options.fitToGeometry;
            if (i) {
              if (!this.fitToGeometryCache)
                if ("MultiPoint" === i.type) {
                  let e = i.coordinates.map((e) => t.forward(e)),
                    s = e.map((t) => t[0]),
                    o = e.map((t) => t[1]);
                  this.fitToGeometryCache = {
                    x1: Math.min.apply(0, s),
                    x2: Math.max.apply(0, s),
                    y1: Math.min.apply(0, o),
                    y2: Math.max.apply(0, o),
                  };
                } else this.fitToGeometryCache = ej(t.path(i));
              return this.fitToGeometryCache;
            }
            return this.projection.bounds || eU.compositeBounds(e);
          }
          getScale() {
            return (256 / 400.979322) * Math.pow(2, this.zoom);
          }
          getSVGTransform() {
            let { x: t, y: e, width: i, height: s } = this.playingField,
              o = this.projection.forward(this.center),
              r = this.projection.hasCoordinates ? -1 : 1,
              a = this.getScale(),
              n = a * r,
              l = t + i / 2 - o[0] * a,
              h = e + s / 2 - o[1] * n;
            return { scaleX: a, scaleY: n, translateX: l, translateY: h };
          }
          lonLatToPixels(t) {
            let e = this.lonLatToProjectedUnits(t);
            if (e) return this.projectedUnitsToPixels(e);
          }
          lonLatToProjectedUnits(t) {
            let e = this.chart,
              i = e.mapTransforms;
            if (i) {
              for (let s in i)
                if (Object.hasOwnProperty.call(i, s) && i[s].hitZone) {
                  let o = e.transformFromLatLon(t, i[s]);
                  if (o && eA(o, i[s].hitZone.coordinates[0])) return o;
                }
              return e.transformFromLatLon(t, i.default);
            }
            for (let e of this.insets)
              if (
                e.options.geoBounds &&
                eA({ x: t.lon, y: t.lat }, e.options.geoBounds.coordinates[0])
              ) {
                let i = e.projection.forward([t.lon, t.lat]),
                  s = e.projectedUnitsToPixels({ x: i[0], y: i[1] });
                return this.pixelsToProjectedUnits(s);
              }
            let s = this.projection.forward([t.lon, t.lat]);
            if (!s.outside) return { x: s[0], y: s[1] };
          }
          projectedUnitsToLonLat(t) {
            let e = this.chart,
              i = e.mapTransforms;
            if (i) {
              for (let s in i)
                if (
                  Object.hasOwnProperty.call(i, s) &&
                  i[s].hitZone &&
                  eA(t, i[s].hitZone.coordinates[0])
                )
                  return e.transformToLatLon(t, i[s]);
              return e.transformToLatLon(t, i.default);
            }
            let s = this.projectedUnitsToPixels(t);
            for (let t of this.insets)
              if (t.hitZone && eA(s, t.hitZone.coordinates[0])) {
                let e = t.pixelsToProjectedUnits(s),
                  i = t.projection.inverse([e.x, e.y]);
                return { lon: i[0], lat: i[1] };
              }
            let o = this.projection.inverse([t.x, t.y]);
            return { lon: o[0], lat: o[1] };
          }
          recommendMapView(t, e, i = !1) {
            this.recommendedMapView = {};
            let s = e.map((t) => this.getGeoMap(t)),
              o = [];
            s.forEach((t) => {
              if (
                t &&
                (Object.keys(this.recommendedMapView).length ||
                  (this.recommendedMapView = t["hc-recommended-mapview"] || {}),
                t.bbox)
              ) {
                let [e, i, s, r] = t.bbox;
                o.push({ x1: e, y1: i, x2: s, y2: r });
              }
            });
            let r = o.length && eU.compositeBounds(o);
            eB(
              this,
              "onRecommendMapView",
              { geoBounds: r, chart: t },
              function () {
                if (r && this.recommendedMapView) {
                  if (!this.recommendedMapView.projection) {
                    let { x1: t, y1: e, x2: i, y2: s } = r;
                    this.recommendedMapView.projection =
                      i - t > 180 && s - e > 90
                        ? {
                            name: "EqualEarth",
                            parallels: [0, 0],
                            rotation: [0],
                          }
                        : {
                            name: "LambertConformalConic",
                            parallels: [e, s],
                            rotation: [-(t + i) / 2],
                          };
                  }
                  this.recommendedMapView.insets ||
                    (this.recommendedMapView.insets = void 0);
                }
              }
            ),
              (this.geoMap = s[0]),
              i &&
                t.hasRendered &&
                !t.userOptions.mapView?.projection &&
                this.recommendedMapView &&
                this.update(this.recommendedMapView);
          }
          redraw(t) {
            this.chart.series.forEach((t) => {
              t.useMapGeometry && (t.isDirty = !0);
            }),
              this.chart.redraw(t);
          }
          setView(t, e, i = !0, s) {
            t && (this.center = t),
              "number" == typeof e &&
                ("number" == typeof this.minZoom &&
                  (e = Math.max(e, this.minZoom)),
                "number" == typeof this.options.maxZoom &&
                  (e = Math.min(e, this.options.maxZoom)),
                eD(e) && (this.zoom = e));
            let o = this.getProjectedBounds();
            if (o) {
              let t = this.projection.forward(this.center),
                { x: e, y: i, width: s, height: r } = this.playingField,
                a = this.getScale(),
                n = this.projectedUnitsToPixels({ x: o.x1, y: o.y1 }),
                l = this.projectedUnitsToPixels({ x: o.x2, y: o.y2 }),
                h = [(o.x1 + o.x2) / 2, (o.y1 + o.y2) / 2];
              if (!this.chart.series.some((t) => t.isDrilling)) {
                let o = n.x,
                  p = l.y,
                  d = l.x,
                  c = n.y;
                d - o < s
                  ? (t[0] = h[0])
                  : o < e && d < e + s
                  ? (t[0] += Math.max(o - e, d - s - e) / a)
                  : d > e + s &&
                    o > e &&
                    (t[0] += Math.min(d - s - e, o - e) / a),
                  c - p < r
                    ? (t[1] = h[1])
                    : p < i && c < i + r
                    ? (t[1] -= Math.max(p - i, c - r - i) / a)
                    : c > i + r &&
                      p > i &&
                      (t[1] -= Math.min(c - r - i, p - i) / a),
                  (this.center = this.projection.inverse(t));
              }
              this.insets.forEach((t) => {
                t.options.field &&
                  ((t.hitZone = t.getHitZone()),
                  (t.playingField = t.getField()));
              }),
                this.render();
            }
            eB(this, "afterSetView"), i && this.redraw(s);
          }
          projectedUnitsToPixels(t) {
            let e = this.getScale(),
              i = this.projection.forward(this.center),
              s = this.playingField,
              o = s.x + s.width / 2,
              r = s.y + s.height / 2;
            return { x: o - e * (i[0] - t.x), y: r + e * (i[1] - t.y) };
          }
          pixelsToLonLat(t) {
            return this.projectedUnitsToLonLat(this.pixelsToProjectedUnits(t));
          }
          pixelsToProjectedUnits(t) {
            let { x: e, y: i } = t,
              s = this.getScale(),
              o = this.projection.forward(this.center),
              r = this.playingField,
              a = r.x + r.width / 2,
              n = r.y + r.height / 2;
            return { x: o[0] + (e - a) / s, y: o[1] - (i - n) / s };
          }
          setUpEvents() {
            let t,
              e,
              i,
              { chart: s } = this,
              o = (o) => {
                let { lastTouches: r, pinchDown: a } = s.pointer,
                  n = this.projection,
                  l = o.touches,
                  { mouseDownX: h, mouseDownY: p } = s,
                  d = 0;
                if (
                  (a?.length === 1
                    ? ((h = a[0].chartX), (p = a[0].chartY))
                    : a?.length === 2 &&
                      ((h = (a[0].chartX + a[1].chartX) / 2),
                      (p = (a[0].chartY + a[1].chartY) / 2)),
                  l?.length === 2 &&
                    r &&
                    (d =
                      Math.log(
                        Math.sqrt(
                          Math.pow(r[0].chartX - r[1].chartX, 2) +
                            Math.pow(r[0].chartY - r[1].chartY, 2)
                        ) /
                          Math.sqrt(
                            Math.pow(l[0].chartX - l[1].chartX, 2) +
                              Math.pow(l[0].chartY - l[1].chartY, 2)
                          )
                      ) / Math.log(0.5)),
                  eD(h) && eD(p))
                ) {
                  let r = `${h},${p}`,
                    { chartX: a, chartY: c } = o.originalEvent;
                  l?.length === 2 &&
                    ((a = (l[0].chartX + l[1].chartX) / 2),
                    (c = (l[0].chartY + l[1].chartY) / 2)),
                    r !== e &&
                      ((e = r),
                      (t = this.projection.forward(this.center)),
                      (i = (
                        this.projection.options.rotation || [0, 0]
                      ).slice()));
                  let u = n.def && n.def.bounds,
                    m = (u && eW(u, this.playingField)) || -1 / 0;
                  if (
                    "Orthographic" === n.options.name &&
                    2 > (l?.length || 0) &&
                    (this.minZoom || 1 / 0) < 1.3 * m
                  ) {
                    let t =
                      440 /
                      (this.getScale() * Math.min(s.plotWidth, s.plotHeight));
                    if (i) {
                      let e = (h - a) * t - i[0],
                        o = eS(-i[1] - (p - c) * t, -80, 80),
                        r = this.zoom;
                      this.update({ projection: { rotation: [-e, -o] } }, !1),
                        this.fitToBounds(void 0, void 0, !1),
                        (this.zoom = r),
                        s.redraw(!1);
                    }
                  } else if (eD(a) && eD(c)) {
                    let e = this.getScale(),
                      i = this.projection.hasCoordinates ? 1 : -1,
                      s = this.projection.inverse([
                        t[0] + (h - a) / e,
                        t[1] - ((p - c) / e) * i,
                      ]);
                    isNaN(s[0] + s[1]) || this.zoomBy(d, s, void 0, !1);
                  }
                  o.preventDefault();
                }
              };
            ez(s, "pan", o),
              ez(s, "touchpan", o),
              ez(s, "selection", (t) => {
                if (t.resetSelection) this.zoomBy();
                else {
                  let e = t.x - s.plotLeft,
                    i = t.y - s.plotTop,
                    { y: o, x: r } = this.pixelsToProjectedUnits({
                      x: e,
                      y: i,
                    }),
                    { y: a, x: n } = this.pixelsToProjectedUnits({
                      x: e + t.width,
                      y: i + t.height,
                    });
                  this.fitToBounds(
                    { x1: r, y1: o, x2: n, y2: a },
                    void 0,
                    !0,
                    !t.originalEvent.touches && void 0
                  ),
                    /^touch/.test(t.originalEvent.type) || s.showResetZoom(),
                    t.preventDefault();
                }
              });
          }
          render() {
            this.group ||
              (this.group = this.chart.renderer
                .g("map-view")
                .attr({ zIndex: 4 })
                .add());
          }
          update(t, e = !0, i) {
            let s = t.projection,
              o = s && eL.toString(s) !== eL.toString(this.options.projection),
              r = !1;
            eN(!0, this.userOptions, t),
              eN(!0, this.options, t),
              "insets" in t &&
                (this.insets.forEach((t) => t.destroy()),
                (this.insets.length = 0),
                (r = !0)),
              (o || "fitToGeometry" in t) && delete this.fitToGeometryCache,
              (o || r) &&
                (this.chart.series.forEach((t) => {
                  let e = t.transformGroups;
                  if (
                    (t.clearBounds && t.clearBounds(),
                    (t.isDirty = !0),
                    (t.isDirtyData = !0),
                    r && e)
                  )
                    for (; e.length > 1; ) {
                      let t = e.pop();
                      t && t.destroy();
                    }
                }),
                o && (this.projection = new eL(this.options.projection)),
                r && this.createInsets(),
                !t.center &&
                  Object.hasOwnProperty.call(t, "zoom") &&
                  !eD(t.zoom) &&
                  this.fitToBounds(void 0, void 0, !1)),
              t.center || eD(t.zoom)
                ? this.setView(this.options.center, t.zoom, !1)
                : "fitToGeometry" in t && this.fitToBounds(void 0, void 0, !1),
              e && this.chart.redraw(i);
          }
          zoomBy(t, e, i, s) {
            let o = this.chart,
              r = this.projection.forward(this.center);
            if ("number" == typeof t) {
              let a,
                n,
                l,
                h = this.zoom + t;
              if (i) {
                let [t, e] = i,
                  s = this.getScale(),
                  a = t - o.plotLeft - o.plotWidth / 2,
                  h = e - o.plotTop - o.plotHeight / 2;
                (n = r[0] + a / s), (l = r[1] + h / s);
              }
              if ("number" == typeof n && "number" == typeof l) {
                let t = 1 - Math.pow(2, this.zoom) / Math.pow(2, h),
                  e = r[0] - n,
                  i = r[1] - l;
                (r[0] -= e * t),
                  (r[1] += i * t),
                  (a = this.projection.inverse(r));
              }
              this.setView(e || a, h, void 0, s);
            } else this.fitToBounds(void 0, void 0, void 0, s);
          }
        }
        class eF extends eU {
          constructor(t, e) {
            if (
              (super(t.chart, e),
              (this.id = e.id),
              (this.mapView = t),
              (this.options = eN(
                { center: [0, 0] },
                t.options.insetOptions,
                e
              )),
              (this.allBounds = []),
              this.options.geoBounds)
            ) {
              let e = t.projection.path(this.options.geoBounds);
              (this.geoBoundsProjectedBox = ej(e)),
                (this.geoBoundsProjectedPolygon = e.map((t) => [
                  t[1] || 0,
                  t[2] || 0,
                ]));
            }
          }
          getField(t = !0) {
            let e = this.hitZone;
            if (e) {
              let i = t ? this.padding : [0, 0, 0, 0],
                s = e.coordinates[0],
                o = s.map((t) => t[0]),
                r = s.map((t) => t[1]),
                a = Math.min.apply(0, o) + i[3],
                n = Math.max.apply(0, o) - i[1],
                l = Math.min.apply(0, r) + i[0],
                h = Math.max.apply(0, r) - i[2];
              if (eD(a) && eD(l))
                return { x: a, y: l, width: n - a, height: h - l };
            }
            return super.getField.call(this, t);
          }
          getHitZone() {
            let { chart: t, mapView: e, options: i } = this,
              { coordinates: s } = i.field || {};
            if (s) {
              let o = s[0];
              if ("percent" === i.units) {
                let s =
                  ("mapBoundingBox" === i.relativeTo && e.getMapBBox()) ||
                  eN(t.plotBox, { x: 0, y: 0 });
                o = o.map((t) => [
                  eR(`${t[0]}%`, s.width, s.x),
                  eR(`${t[1]}%`, s.height, s.y),
                ]);
              }
              return { type: "Polygon", coordinates: [o] };
            }
          }
          getProjectedBounds() {
            return eU.compositeBounds(this.allBounds);
          }
          isInside(t) {
            let { geoBoundsProjectedBox: e, geoBoundsProjectedPolygon: i } =
              this;
            return !!(
              e &&
              t.x >= e.x1 &&
              t.x <= e.x2 &&
              t.y >= e.y1 &&
              t.y <= e.y2 &&
              i &&
              eA(t, i)
            );
          }
          render() {
            let { chart: t, mapView: e, options: i } = this,
              s = i.borderPath || i.field;
            if (s && e.group) {
              let o = !0;
              this.border ||
                ((this.border = t.renderer
                  .path()
                  .addClass("highcharts-mapview-inset-border")
                  .add(e.group)),
                (o = !1)),
                t.styledMode ||
                  this.border.attr({
                    stroke: i.borderColor,
                    "stroke-width": i.borderWidth,
                  });
              let r = this.border.strokeWidth(),
                a =
                  ("mapBoundingBox" === i.relativeTo && e.getMapBBox()) ||
                  e.playingField,
                n = (s.coordinates || []).reduce(
                  (e, s) =>
                    s.reduce((e, s, o) => {
                      let [n, l] = s;
                      return (
                        "percent" === i.units &&
                          ((n = t.plotLeft + eR(`${n}%`, a.width, a.x)),
                          (l = t.plotTop + eR(`${l}%`, a.height, a.y))),
                        (n = eI(n, r)),
                        (l = eI(l, r)),
                        e.push(0 === o ? ["M", n, l] : ["L", n, l]),
                        e
                      );
                    }, e),
                  []
                );
              this.border[o ? "animate" : "attr"]({ d: n });
            }
          }
          destroy() {
            this.border && (this.border = this.border.destroy()),
              this.eventsToUnbind.forEach((t) => t());
          }
          setUpEvents() {}
        }
        let { animObject: eZ, stop: e_ } = L(),
          { noop: eK } = L(),
          { splitPath: eq } = tY,
          { column: e$, scatter: eJ } = W().seriesTypes,
          {
            extend: eQ,
            find: e0,
            fireEvent: e1,
            getNestedProperty: e2,
            isArray: e6,
            defined: e3,
            isNumber: e8,
            isObject: e7,
            merge: e9,
            objectEach: e4,
            pick: e5,
            splat: it,
          } = L();
        class ie extends eJ {
          constructor() {
            super(...arguments), (this.processedData = []);
          }
          animate(t) {
            let { chart: e, group: i } = this,
              s = eZ(this.options.animation);
            t
              ? i.attr({
                  translateX: e.plotLeft + e.plotWidth / 2,
                  translateY: e.plotTop + e.plotHeight / 2,
                  scaleX: 0.001,
                  scaleY: 0.001,
                })
              : i.animate(
                  {
                    translateX: e.plotLeft,
                    translateY: e.plotTop,
                    scaleX: 1,
                    scaleY: 1,
                  },
                  s
                );
          }
          clearBounds() {
            this.points.forEach((t) => {
              delete t.bounds, delete t.insetIndex, delete t.projectedPath;
            }),
              delete this.bounds;
          }
          doFullTranslate() {
            return !!(
              this.isDirtyData ||
              this.chart.isResizing ||
              !this.hasRendered
            );
          }
          drawMapDataLabels() {
            super.drawDataLabels(),
              this.dataLabelsGroup &&
                this.dataLabelsGroup.clip(this.chart.clipRect);
          }
          drawPoints() {
            let t = this,
              { chart: e, group: i, transformGroups: s = [] } = this,
              { mapView: o, renderer: r } = e;
            if (o) {
              (this.transformGroups = s), s[0] || (s[0] = r.g().add(i));
              for (let t = 0, e = o.insets.length; t < e; ++t)
                s[t + 1] || s.push(r.g().add(i));
              this.doFullTranslate() &&
                (this.points.forEach((t) => {
                  let { graphic: e } = t;
                  (t.group =
                    s["number" == typeof t.insetIndex ? t.insetIndex + 1 : 0]),
                    e && e.parentGroup !== t.group && e.add(t.group);
                }),
                e$.prototype.drawPoints.apply(this),
                this.points.forEach((i) => {
                  let s = i.graphic;
                  if (s) {
                    let o = s.animate,
                      r = "";
                    i.name &&
                      (r +=
                        "highcharts-name-" +
                        i.name.replace(/ /g, "-").toLowerCase()),
                      i.properties?.["hc-key"] &&
                        (r +=
                          " highcharts-key-" +
                          i.properties["hc-key"].toString().toLowerCase()),
                      r && s.addClass(r),
                      e.styledMode &&
                        s.css(
                          this.pointAttribs(
                            i,
                            (i.selected && "select") || void 0
                          )
                        ),
                      s.attr({
                        visibility:
                          !i.visible && (i.visible || i.isNull)
                            ? "hidden"
                            : "inherit",
                      }),
                      (s.animate = function (i, r, a) {
                        let n = e8(i["stroke-width"]) && !e8(s["stroke-width"]),
                          l = e8(s["stroke-width"]) && !e8(i["stroke-width"]);
                        if (n || l) {
                          let o =
                            e5(t.getStrokeWidth(t.options), 1) /
                            (e.mapView?.getScale() || 1);
                          n && (s["stroke-width"] = o),
                            l && (i["stroke-width"] = o);
                        }
                        return o.call(
                          s,
                          i,
                          r,
                          l
                            ? function () {
                                s.element.removeAttribute("stroke-width"),
                                  delete s["stroke-width"],
                                  a && a.apply(this, arguments);
                              }
                            : a
                        );
                      });
                  }
                })),
                s.forEach((i, s) => {
                  let a = (0 === s ? o : o.insets[s - 1]).getSVGTransform(),
                    n = e5(this.getStrokeWidth(this.options), 1),
                    l = a.scaleX,
                    h = a.scaleY > 0 ? 1 : -1,
                    p = (e) => {
                      (t.points || []).forEach((t) => {
                        let i,
                          s = t.graphic;
                        s?.["stroke-width"] &&
                          (i = this.getStrokeWidth(t.options)) &&
                          s.attr({ "stroke-width": i / e });
                      });
                    };
                  if (
                    r.globalAnimation &&
                    e.hasRendered &&
                    o.allowTransformAnimation
                  ) {
                    let t = Number(i.attr("translateX")),
                      e = Number(i.attr("translateY")),
                      s = Number(i.attr("scaleX")),
                      o = (o, r) => {
                        let d = s + (l - s) * r.pos;
                        i.attr({
                          translateX: t + (a.translateX - t) * r.pos,
                          translateY: e + (a.translateY - e) * r.pos,
                          scaleX: d,
                          scaleY: d * h,
                          "stroke-width": n / d,
                        }),
                          p(d);
                      },
                      d = e9(eZ(r.globalAnimation)),
                      c = d.step;
                    (d.step = function () {
                      c && c.apply(this, arguments), o.apply(this, arguments);
                    }),
                      i.attr({ animator: 0 }).animate(
                        { animator: 1 },
                        d,
                        function () {
                          "boolean" != typeof r.globalAnimation &&
                            r.globalAnimation.complete &&
                            r.globalAnimation.complete({ applyDrilldown: !0 }),
                            e1(this, "mapZoomComplete");
                        }.bind(this)
                      );
                  } else e_(i), i.attr(e9(a, { "stroke-width": n / l })), p(l);
                }),
                this.isDrilling || this.drawMapDataLabels();
            }
          }
          getProjectedBounds() {
            if (!this.bounds && this.chart.mapView) {
              let { insets: t, projection: e } = this.chart.mapView,
                i = [];
              (this.points || []).forEach((s) => {
                if (s.path || s.geometry) {
                  if (
                    ("string" == typeof s.path
                      ? (s.path = eq(s.path))
                      : e6(s.path) &&
                        "M" === s.path[0] &&
                        (s.path = this.chart.renderer.pathToSegments(s.path)),
                    !s.bounds)
                  ) {
                    let i = s.getProjectedBounds(e);
                    if (i) {
                      s.labelrank = e5(
                        s.labelrank,
                        (i.x2 - i.x1) * (i.y2 - i.y1)
                      );
                      let { midX: e, midY: o } = i;
                      if (t && e8(e) && e8(o)) {
                        let r = e0(t, (t) => t.isInside({ x: e, y: o }));
                        r &&
                          (delete s.projectedPath,
                          (i = s.getProjectedBounds(r.projection)) &&
                            r.allBounds.push(i),
                          (s.insetIndex = t.indexOf(r)));
                      }
                      s.bounds = i;
                    }
                  }
                  s.bounds && void 0 === s.insetIndex && i.push(s.bounds);
                }
              }),
                (this.bounds = eU.compositeBounds(i));
            }
            return this.bounds;
          }
          getStrokeWidth(t) {
            let e = this.pointAttrToOptions;
            return t[e?.["stroke-width"] || "borderWidth"];
          }
          hasData() {
            return !!this.dataTable.rowCount;
          }
          pointAttribs(t, e) {
            let { mapView: i, styledMode: s } = t.series.chart,
              o = s
                ? this.colorAttribs(t)
                : e$.prototype.pointAttribs.call(this, t, e),
              r = this.getStrokeWidth(t.options);
            if (e) {
              let i = e9(
                  this.options.states && this.options.states[e],
                  (t.options.states && t.options.states[e]) || {}
                ),
                s = this.getStrokeWidth(i);
              e3(s) && (r = s), (o.stroke = i.borderColor ?? t.color);
            }
            r && i && (r /= i.getScale());
            let a = this.getStrokeWidth(this.options);
            return (
              o.dashstyle && i && e8(a) && (r = a / i.getScale()),
              t.visible || (o.fill = this.options.nullColor),
              e3(r) ? (o["stroke-width"] = r) : delete o["stroke-width"],
              (o["stroke-linecap"] = o["stroke-linejoin"] =
                this.options.linecap),
              o
            );
          }
          updateData() {
            return (
              !this.processedData && super.updateData.apply(this, arguments)
            );
          }
          setData(t, e = !0, i, s) {
            delete this.bounds,
              super.setData(t, !1, void 0, s),
              this.processData(),
              this.generatePoints(),
              e && this.chart.redraw(i);
          }
          dataColumnKeys() {
            return this.pointArrayMap;
          }
          processData() {
            let t,
              e,
              i,
              s = this.options,
              o = s.data,
              r = this.chart,
              a = r.options.chart,
              n = this.joinBy,
              l = s.keys || this.pointArrayMap,
              h = [],
              p = {},
              d = this.chart.mapView,
              c = d && (e7(s.mapData, !0) ? d.getGeoMap(s.mapData) : d.geoMap),
              u = (r.mapTransforms =
                a.mapTransforms || c?.["hc-transform"] || r.mapTransforms);
            u &&
              e4(u, (t) => {
                t.rotation &&
                  ((t.cosAngle = Math.cos(t.rotation)),
                  (t.sinAngle = Math.sin(t.rotation)));
              }),
              e6(s.mapData)
                ? (i = s.mapData)
                : c &&
                  "FeatureCollection" === c.type &&
                  ((this.mapTitle = c.title),
                  (i = L().geojson(c, this.type, this))),
              (this.processedData = []);
            let m = this.processedData;
            if (o) {
              let t;
              for (let e = 0, i = o.length; e < i; ++e) {
                if (e8((t = o[e]))) m[e] = { value: t };
                else if (e6(t)) {
                  let i = 0;
                  (m[e] = {}),
                    !s.keys &&
                      t.length > l.length &&
                      "string" == typeof t[0] &&
                      ((m[e]["hc-key"] = t[0]), ++i);
                  for (let s = 0; s < l.length; ++s, ++i)
                    l[s] &&
                      void 0 !== t[i] &&
                      (l[s].indexOf(".") > 0
                        ? t$.prototype.setNestedProperty(m[e], t[i], l[s])
                        : (m[e][l[s]] = t[i]));
                } else m[e] = o[e];
                n && "_i" === n[0] && (m[e]._i = e);
              }
            }
            if (i) {
              (this.mapData = i), (this.mapMap = {});
              for (let s = 0; s < i.length; s++)
                (e = (t = i[s]).properties),
                  (t._i = s),
                  n[0] && e && e[n[0]] && (t[n[0]] = e[n[0]]),
                  (p[t[n[0]]] = t);
              if (((this.mapMap = p), n[1])) {
                let t = n[1];
                m.forEach((e) => {
                  let i = e2(t, e);
                  p[i] && h.push(p[i]);
                });
              }
              if (s.allAreas) {
                if (n[1]) {
                  let t = n[1];
                  m.forEach((e) => {
                    h.push(e2(t, e));
                  });
                }
                let t =
                  "|" +
                  h
                    .map(function (t) {
                      return t && t[n[0]];
                    })
                    .join("|") +
                  "|";
                i.forEach((e) => {
                  (n[0] && -1 !== t.indexOf("|" + e[n[0]] + "|")) ||
                    m.push(e9(e, { value: null }));
                });
              }
            }
            this.dataTable.rowCount = m.length;
          }
          setOptions(t) {
            let e = super.setOptions(t),
              i = e.joinBy;
            return (
              null === e.joinBy && (i = "_i"),
              i &&
                ((this.joinBy = it(i)),
                this.joinBy[1] || (this.joinBy[1] = this.joinBy[0])),
              e
            );
          }
          translate() {
            let t = this.doFullTranslate(),
              e = this.chart.mapView,
              i = e?.projection;
            if (
              (this.chart.hasRendered &&
                (this.isDirtyData || !this.hasRendered) &&
                (this.processData(),
                this.generatePoints(),
                delete this.bounds,
                !e ||
                e.userOptions.center ||
                e8(e.userOptions.zoom) ||
                e.zoom !== e.minZoom
                  ? this.getProjectedBounds()
                  : e.fitToBounds(void 0, void 0, !1)),
              e)
            ) {
              let s = e.getSVGTransform();
              this.points.forEach((o) => {
                let r =
                  (e8(o.insetIndex) &&
                    e.insets[o.insetIndex].getSVGTransform()) ||
                  s;
                r &&
                  o.bounds &&
                  e8(o.bounds.midX) &&
                  e8(o.bounds.midY) &&
                  ((o.plotX = o.bounds.midX * r.scaleX + r.translateX),
                  (o.plotY = o.bounds.midY * r.scaleY + r.translateY)),
                  t &&
                    ((o.shapeType = "path"),
                    (o.shapeArgs = { d: t$.getProjectedPath(o, i) })),
                  !o.hiddenInDataClass &&
                    (o.projectedPath && !o.projectedPath.length
                      ? o.setVisible(!1)
                      : o.visible || o.setVisible(!0));
              });
            }
            e1(this, "afterTranslate");
          }
          update(t) {
            t.mapData &&
              this.chart.mapView?.recommendMapView(
                this.chart,
                [
                  this.chart.options.chart.map,
                  ...(this.chart.options.series || []).map((e, i) =>
                    i === this._i ? t.mapData : e.mapData
                  ),
                ],
                !0
              ),
              super.update.apply(this, arguments);
          }
        }
        (ie.defaultOptions = e9(eJ.defaultOptions, {
          affectsMapView: !0,
          animation: !1,
          dataLabels: {
            crop: !1,
            formatter: function () {
              let { numberFormatter: t } = this.series.chart,
                { value: e } = this.point;
              return tJ(e) ? t(e, -1) : this.point.name || "";
            },
            inside: !0,
            overflow: !1,
            padding: 0,
            verticalAlign: "middle",
          },
          linecap: "round",
          marker: null,
          nullColor: "#f7f7f7",
          stickyTracking: !1,
          tooltip: {
            followPointer: !0,
            pointFormat: "{point.name}: {point.value}<br/>",
          },
          turboThreshold: 0,
          allAreas: !0,
          borderColor: "#e6e6e6",
          borderWidth: 1,
          joinBy: "hc-key",
          states: {
            hover: { halo: void 0, borderColor: "#666666", borderWidth: 2 },
            normal: { animation: !0 },
            select: { color: "#cccccc" },
          },
          legendSymbol: "rectangle",
        })),
          eQ(ie.prototype, {
            type: "map",
            axisTypes: tP.seriesMembers.axisTypes,
            colorAttribs: tP.seriesMembers.colorAttribs,
            colorKey: tP.seriesMembers.colorKey,
            directTouch: !0,
            drawDataLabels: eK,
            drawGraph: eK,
            forceDL: !0,
            getCenter: tE.getCenter,
            getExtremesFromAll: !0,
            getSymbol: eK,
            isCartesian: !1,
            parallelArrays: tP.seriesMembers.parallelArrays,
            pointArrayMap: tP.seriesMembers.pointArrayMap,
            pointClass: t$,
            preserveAspectRatio: !0,
            searchPoint: eK,
            trackerGroups: tP.seriesMembers.trackerGroups,
            useMapGeometry: !0,
          }),
          tP.compose(ie),
          W().registerSeriesType("map", ie);
        let ii = ie,
          { extend: is, merge: io } = L();
        class ir extends ii {
          pointAttribs(t, e) {
            let i = super.pointAttribs(t, e);
            return (i.fill = this.options.fillColor), i;
          }
        }
        (ir.defaultOptions = io(ii.defaultOptions, {
          lineWidth: 1,
          fillColor: "none",
          legendSymbol: "lineMarker",
        })),
          is(ir.prototype, {
            type: "mapline",
            colorProp: "stroke",
            pointAttrToOptions: {
              stroke: "color",
              "stroke-width": "lineWidth",
            },
          }),
          W().registerSeriesType("mapline", ir);
        let { scatter: ia } = W().seriesTypes,
          { isNumber: il } = L();
        class ih extends ia.prototype.pointClass {
          isValid() {
            return !!(
              this.options.geometry ||
              (il(this.x) && il(this.y)) ||
              (il(this.options.lon) && il(this.options.lat))
            );
          }
        }
        w(632);
        let { noop: ip } = L(),
          { map: id, scatter: ic } = W().seriesTypes,
          { extend: iu, fireEvent: im, isNumber: ig, merge: ib } = L();
        class iy extends ic {
          constructor() {
            super(...arguments), (this.clearBounds = id.prototype.clearBounds);
          }
          drawDataLabels() {
            super.drawDataLabels(),
              this.dataLabelsGroup &&
                this.dataLabelsGroup.clip(this.chart.clipRect);
          }
          projectPoint(t) {
            let e = this.chart.mapView;
            if (e) {
              let { geometry: i, lon: s, lat: o } = t,
                r = i && "Point" === i.type && i.coordinates;
              if ((ig(s) && ig(o) && (r = [s, o]), r))
                return e.lonLatToProjectedUnits({ lon: r[0], lat: r[1] });
            }
          }
          translate() {
            let t = this.chart.mapView;
            if (
              (this.generatePoints(),
              this.getProjectedBounds &&
                this.isDirtyData &&
                (delete this.bounds, this.getProjectedBounds()),
              t)
            ) {
              let e = t.getSVGTransform(),
                { hasCoordinates: i } = t.projection;
              this.points.forEach((s) => {
                let o,
                  { x: r, y: a } = s,
                  n =
                    (ig(s.insetIndex) &&
                      t.insets[s.insetIndex].getSVGTransform()) ||
                    e,
                  l =
                    this.projectPoint(s.options) ||
                    (s.properties && this.projectPoint(s.properties));
                if (
                  (l
                    ? ((r = l.x), (a = l.y))
                    : s.bounds &&
                      ((r = s.bounds.midX),
                      (a = s.bounds.midY),
                      n &&
                        ig(r) &&
                        ig(a) &&
                        ((s.plotX = r * n.scaleX + n.translateX),
                        (s.plotY = a * n.scaleY + n.translateY),
                        (o = !0))),
                  ig(r) && ig(a))
                ) {
                  if (!o) {
                    let e = t.projectedUnitsToPixels({ x: r, y: a });
                    (s.plotX = e.x),
                      (s.plotY = i ? e.y : this.chart.plotHeight - e.y);
                  }
                } else s.y = s.plotX = s.plotY = void 0;
                (s.isInside = this.isPointInside(s)),
                  (s.zone = this.zones.length ? s.getZone() : void 0);
              });
            }
            im(this, "afterTranslate");
          }
        }
        (iy.defaultOptions = ib(ic.defaultOptions, {
          dataLabels: {
            crop: !1,
            defer: !1,
            enabled: !0,
            formatter: function () {
              return this.point.name;
            },
            overflow: !1,
            style: { color: "#000000" },
          },
          legendSymbol: "lineMarker",
        })),
          (tN().prototype.symbols.mapmarker = (t, e, i, s, o) => {
            let r,
              a,
              n = o && "legend" === o.context;
            n
              ? ((r = t + i / 2), (a = e + s))
              : o &&
                "number" == typeof o.anchorX &&
                "number" == typeof o.anchorY
              ? ((r = o.anchorX), (a = o.anchorY))
              : ((r = t + i / 2), (a = e + s / 2), (e -= s));
            let l = n ? s / 3 : s / 2;
            return [
              ["M", r, a],
              ["C", r, a, r - l, e + 1.5 * l, r - l, e + l],
              ["A", l, l, 1, 1, 1, r + l, e + l],
              ["C", r + l, e + 1.5 * l, r, a, r, a],
              ["Z"],
            ];
          }),
          iu(iy.prototype, {
            type: "mappoint",
            axisTypes: ["colorAxis"],
            forceDL: !0,
            isCartesian: !1,
            pointClass: ih,
            searchPoint: ip,
            useMapGeometry: !0,
          }),
          W().registerSeriesType("mappoint", iy);
        let ix = {
            borderColor: void 0,
            borderWidth: 2,
            className: void 0,
            color: void 0,
            connectorClassName: void 0,
            connectorColor: void 0,
            connectorDistance: 60,
            connectorWidth: 1,
            enabled: !1,
            labels: {
              className: void 0,
              allowOverlap: !1,
              format: "",
              formatter: void 0,
              align: "right",
              style: { fontSize: "0.9em", color: "#000000" },
              x: 0,
              y: 0,
            },
            maxSize: 60,
            minSize: 10,
            legendIndex: 0,
            ranges: {
              value: void 0,
              borderColor: void 0,
              color: void 0,
              connectorColor: void 0,
            },
            sizeBy: "area",
            sizeByAbsoluteValue: !1,
            zIndex: 1,
            zThreshold: 0,
          },
          { noop: iM } = L(),
          {
            arrayMax: iv,
            arrayMin: iw,
            isNumber: iC,
            merge: iT,
            pick: iL,
            stableSort: iP,
          } = L(),
          iA = class {
            constructor(t, e) {
              (this.setState = iM), this.init(t, e);
            }
            init(t, e) {
              (this.options = t),
                (this.visible = !0),
                (this.chart = e.chart),
                (this.legend = e);
            }
            addToLegend(t) {
              t.splice(this.options.legendIndex, 0, this);
            }
            drawLegendSymbol(t) {
              let e,
                i = iL(t.options.itemDistance, 20),
                s = this.legendItem || {},
                o = this.options,
                r = o.ranges,
                a = o.connectorDistance;
              if (!r || !r.length || !iC(r[0].value)) {
                t.options.bubbleLegend.autoRanges = !0;
                return;
              }
              iP(r, function (t, e) {
                return e.value - t.value;
              }),
                (this.ranges = r),
                this.setOptions(),
                this.render();
              let n = this.getMaxLabelSize(),
                l = this.ranges[0].radius,
                h = 2 * l;
              (e = (e = a - l + n.width) > 0 ? e : 0),
                (this.maxLabel = n),
                (this.movementX = "left" === o.labels.align ? e : 0),
                (s.labelWidth = h + e + i),
                (s.labelHeight = h + n.height / 2);
            }
            setOptions() {
              let t = this.ranges,
                e = this.options,
                i = this.chart.series[e.seriesIndex],
                s = this.legend.baseline,
                o = { zIndex: e.zIndex, "stroke-width": e.borderWidth },
                r = { zIndex: e.zIndex, "stroke-width": e.connectorWidth },
                a = {
                  align:
                    this.legend.options.rtl || "left" === e.labels.align
                      ? "right"
                      : "left",
                  zIndex: e.zIndex,
                },
                n = i.options.marker.fillOpacity,
                l = this.chart.styledMode;
              t.forEach(function (h, p) {
                l ||
                  ((o.stroke = iL(h.borderColor, e.borderColor, i.color)),
                  (o.fill = h.color || e.color),
                  o.fill || ((o.fill = i.color), (o["fill-opacity"] = n ?? 1)),
                  (r.stroke = iL(h.connectorColor, e.connectorColor, i.color))),
                  (t[p].radius = this.getRangeRadius(h.value)),
                  (t[p] = iT(t[p], { center: t[0].radius - t[p].radius + s })),
                  l ||
                    iT(!0, t[p], {
                      bubbleAttribs: iT(o),
                      connectorAttribs: iT(r),
                      labelAttribs: a,
                    });
              }, this);
            }
            getRangeRadius(t) {
              let e = this.options,
                i = this.options.seriesIndex,
                s = this.chart.series[i],
                o = e.ranges[0].value,
                r = e.ranges[e.ranges.length - 1].value,
                a = e.minSize,
                n = e.maxSize;
              return s.getRadius.call(this, r, o, a, n, t);
            }
            render() {
              let t = this.legendItem || {},
                e = this.chart.renderer,
                i = this.options.zThreshold;
              for (let s of (this.symbols ||
                (this.symbols = {
                  connectors: [],
                  bubbleItems: [],
                  labels: [],
                }),
              (t.symbol = e.g("bubble-legend")),
              (t.label = e
                .g("bubble-legend-item")
                .css(this.legend.itemStyle || {})),
              (t.symbol.translateX = 0),
              (t.symbol.translateY = 0),
              t.symbol.add(t.label),
              t.label.add(t.group),
              this.ranges))
                s.value >= i && this.renderRange(s);
              this.hideOverlappingLabels();
            }
            renderRange(t) {
              let e = this.ranges[0],
                i = this.legend,
                s = this.options,
                o = s.labels,
                r = this.chart,
                a = r.series[s.seriesIndex],
                n = r.renderer,
                l = this.symbols,
                h = l.labels,
                p = t.center,
                d = Math.abs(t.radius),
                c = s.connectorDistance || 0,
                u = o.align,
                m = i.options.rtl,
                g = s.borderWidth,
                f = s.connectorWidth,
                b = e.radius || 0,
                y = p - d - g / 2 + f / 2,
                x = (y % 1 ? 1 : 0.5) - (f % 2 ? 0 : 0.5),
                M = n.styledMode,
                v = m || "left" === u ? -c : c;
              "center" === u &&
                ((v = 0),
                (s.connectorDistance = 0),
                (t.labelAttribs.align = "center")),
                l.bubbleItems.push(
                  n
                    .circle(b, p + x, d)
                    .attr(M ? {} : t.bubbleAttribs)
                    .addClass(
                      (M ? "highcharts-color-" + a.colorIndex + " " : "") +
                        "highcharts-bubble-legend-symbol " +
                        (s.className || "")
                    )
                    .add(this.legendItem.symbol)
                ),
                l.connectors.push(
                  n
                    .path(
                      n.crispLine(
                        [
                          ["M", b, y],
                          ["L", b + v, y],
                        ],
                        s.connectorWidth
                      )
                    )
                    .attr(M ? {} : t.connectorAttribs)
                    .addClass(
                      (M
                        ? "highcharts-color-" + this.options.seriesIndex + " "
                        : "") +
                        "highcharts-bubble-legend-connectors " +
                        (s.connectorClassName || "")
                    )
                    .add(this.legendItem.symbol)
                );
              let w = n
                  .text(this.formatLabel(t))
                  .attr(M ? {} : t.labelAttribs)
                  .css(M ? {} : o.style)
                  .addClass(
                    "highcharts-bubble-legend-labels " +
                      (s.labels.className || "")
                  )
                  .add(this.legendItem.symbol),
                C = {
                  x: b + v + s.labels.x,
                  y: y + s.labels.y + 0.4 * w.getBBox().height,
                };
              w.attr(C), h.push(w), (w.placed = !0), (w.alignAttr = C);
            }
            getMaxLabelSize() {
              let t, e;
              return (
                this.symbols.labels.forEach(function (i) {
                  (e = i.getBBox(!0)),
                    (t = t ? (e.width > t.width ? e : t) : e);
                }),
                t || {}
              );
            }
            formatLabel(t) {
              let e = this.options,
                i = e.labels.formatter,
                s = e.labels.format,
                { numberFormatter: o } = this.chart;
              return s
                ? t1().format(s, t, this.chart)
                : i
                ? i.call(t)
                : o(t.value, 1);
            }
            hideOverlappingLabels() {
              let t = this.chart,
                e = this.options.labels.allowOverlap,
                i = this.symbols;
              !e &&
                i &&
                (t.hideOverlappingLabels(i.labels),
                i.labels.forEach(function (t, e) {
                  t.newOpacity
                    ? t.newOpacity !== t.oldOpacity && i.connectors[e].show()
                    : i.connectors[e].hide();
                }));
            }
            getRanges() {
              let t = this.legend.bubbleLegend,
                e = t.chart.series,
                i = t.options.ranges,
                s,
                o,
                r = Number.MAX_VALUE,
                a = -Number.MAX_VALUE;
              return (
                e.forEach(function (t) {
                  t.isBubble &&
                    !t.ignoreSeries &&
                    (o = t.getColumn("z").filter(iC)).length &&
                    ((r = iL(
                      t.options.zMin,
                      Math.min(
                        r,
                        Math.max(
                          iw(o),
                          !1 === t.options.displayNegative
                            ? t.options.zThreshold
                            : -Number.MAX_VALUE
                        )
                      )
                    )),
                    (a = iL(t.options.zMax, Math.max(a, iv(o)))));
                }),
                (s =
                  r === a
                    ? [{ value: a }]
                    : [
                        { value: r },
                        { value: (r + a) / 2 },
                        { value: a, autoRanges: !0 },
                      ]),
                i.length && i[0].radius && s.reverse(),
                s.forEach(function (t, e) {
                  i && i[e] && (s[e] = iT(i[e], t));
                }),
                s
              );
            }
            predictBubbleSizes() {
              let t = this.chart,
                e = t.legend.options,
                i = e.floating,
                s = "horizontal" === e.layout,
                o = s ? t.legend.lastLineHeight : 0,
                r = t.plotSizeX,
                a = t.plotSizeY,
                n = t.series[this.options.seriesIndex],
                l = n.getPxExtremes(),
                h = Math.ceil(l.minPxSize),
                p = Math.ceil(l.maxPxSize),
                d = Math.min(a, r),
                c,
                u = n.options.maxSize;
              return (
                i || !/%$/.test(u)
                  ? (c = p)
                  : ((c =
                      ((d + o) * (u = parseFloat(u))) / 100 / (u / 100 + 1)),
                    ((s && a - c >= r) || (!s && r - c >= a)) && (c = p)),
                [h, Math.ceil(c)]
              );
            }
            updateRanges(t, e) {
              let i = this.legend.options.bubbleLegend;
              (i.minSize = t), (i.maxSize = e), (i.ranges = this.getRanges());
            }
            correctSizes() {
              let t = this.legend,
                e = this.chart.series[this.options.seriesIndex].getPxExtremes();
              Math.abs(Math.ceil(e.maxPxSize) - this.options.maxSize) > 1 &&
                (this.updateRanges(this.options.minSize, e.maxPxSize),
                t.render());
            }
          },
          { setOptions: ik } = L(),
          { composed: ij } = L(),
          { addEvent: iz, objectEach: iS, pushUnique: iI, wrap: iB } = L();
        function iE(t, e, i) {
          let s,
            o,
            r,
            a = this.legend,
            n = iD(this) >= 0;
          a &&
          a.options.enabled &&
          a.bubbleLegend &&
          a.options.bubbleLegend.autoRanges &&
          n
            ? ((s = a.bubbleLegend.options),
              (o = a.bubbleLegend.predictBubbleSizes()),
              a.bubbleLegend.updateRanges(o[0], o[1]),
              s.placed ||
                ((a.group.placed = !1),
                a.allItems.forEach((t) => {
                  (r = t.legendItem || {}).group &&
                    (r.group.translateY = void 0);
                })),
              a.render(),
              s.placed ||
                (this.getMargins(),
                this.axes.forEach((t) => {
                  t.setScale(),
                    t.updateNames(),
                    iS(t.ticks, function (t) {
                      (t.isNew = !0), (t.isNewLabel = !0);
                    });
                }),
                this.getMargins()),
              (s.placed = !0),
              t.call(this, e, i),
              a.bubbleLegend.correctSizes(),
              iG(a, iV(a)))
            : (t.call(this, e, i),
              a &&
                a.options.enabled &&
                a.bubbleLegend &&
                (a.render(), iG(a, iV(a))));
        }
        function iD(t) {
          let e = t.series,
            i = 0;
          for (; i < e.length; ) {
            if (
              e[i] &&
              e[i].isBubble &&
              e[i].visible &&
              e[i].dataTable.rowCount
            )
              return i;
            i++;
          }
          return -1;
        }
        function iV(t) {
          let e = t.allItems,
            i = [],
            s = e.length,
            o,
            r,
            a,
            n = 0,
            l = 0;
          for (n = 0; n < s; n++)
            if (
              ((r = e[n].legendItem || {}),
              (a = (e[n + 1] || {}).legendItem || {}),
              r.labelHeight && (e[n].itemHeight = r.labelHeight),
              e[n] === e[s - 1] || r.y !== a.y)
            ) {
              for (i.push({ height: 0 }), o = i[i.length - 1]; l <= n; l++)
                e[l].itemHeight > o.height && (o.height = e[l].itemHeight);
              o.step = n;
            }
          return i;
        }
        function iO(t) {
          let e = this.bubbleLegend,
            i = this.options,
            s = i.bubbleLegend,
            o = iD(this.chart);
          e &&
            e.ranges &&
            e.ranges.length &&
            (s.ranges.length && (s.autoRanges = !!s.ranges[0].autoRanges),
            this.destroyItem(e)),
            o >= 0 &&
              i.enabled &&
              s.enabled &&
              ((s.seriesIndex = o),
              (this.bubbleLegend = new iA(s, this)),
              this.bubbleLegend.addToLegend(t.allItems));
        }
        function iN(t) {
          let e;
          if (t.defaultPrevented) return !1;
          let i = t.legendItem,
            s = this.chart,
            o = i.visible;
          this &&
            this.bubbleLegend &&
            ((i.visible = !o),
            (i.ignoreSeries = o),
            (e = iD(s) >= 0),
            this.bubbleLegend.visible !== e &&
              (this.update({ bubbleLegend: { enabled: e } }),
              (this.bubbleLegend.visible = e)),
            (i.visible = o));
        }
        function iG(t, e) {
          let i = t.allItems,
            s = t.options.rtl,
            o,
            r,
            a,
            n,
            l = 0;
          i.forEach((t, i) => {
            (n = t.legendItem || {}).group &&
              ((o = n.group.translateX || 0),
              (r = n.y || 0),
              ((a = t.movementX) || (s && t.ranges)) &&
                ((a = s ? o - t.options.maxSize / 2 : o + a),
                n.group.attr({ translateX: a })),
              i > e[l].step && l++,
              n.group.attr({ translateY: Math.round(r + e[l].height / 2) }),
              (n.y = r + e[l].height / 2));
          });
        }
        let iX = {
          compose: function (t, e) {
            iI(ij, "Series.BubbleLegend") &&
              (ik({ legend: { bubbleLegend: ix } }),
              iB(t.prototype, "drawChartBox", iE),
              iz(e, "afterGetAllItems", iO),
              iz(e, "itemClick", iN));
          },
        };
        var iR = w(260),
          iH = w.n(iR);
        let {
            seriesTypes: {
              scatter: {
                prototype: { pointClass: iW },
              },
            },
          } = W(),
          { extend: iY } = L();
        class iU extends iW {
          haloPath(t) {
            let e = ((t && this.marker && this.marker.radius) || 0) + t;
            if (this.series.chart.inverted) {
              let t = this.pos() || [0, 0],
                { xAxis: i, yAxis: s, chart: o } = this.series,
                r = 2 * e;
              return o.renderer.symbols.circle(
                (i?.len || 0) - t[1] - e,
                (s?.len || 0) - t[0] - e,
                r,
                r
              );
            }
            return iH().prototype.haloPath.call(this, e);
          }
        }
        iY(iU.prototype, { ttBelow: !1 });
        let iF = iU,
          { composed: iZ, noop: i_ } = L(),
          {
            series: iK,
            seriesTypes: {
              column: { prototype: iq },
              scatter: i$,
            },
          } = W(),
          {
            addEvent: iJ,
            arrayMax: iQ,
            arrayMin: i0,
            clamp: i1,
            extend: i2,
            isNumber: i6,
            merge: i3,
            pick: i8,
            pushUnique: i7,
          } = L();
        function i9() {
          let t = this.len,
            { coll: e, isXAxis: i, min: s } = this,
            o = (this.max || 0) - (s || 0),
            r = 0,
            a = t,
            n = t / o,
            l;
          ("xAxis" === e || "yAxis" === e) &&
            (this.series.forEach((t) => {
              if (t.bubblePadding && t.reserveSpace()) {
                (this.allowZoomOutside = !0), (l = !0);
                let e = t.getColumn(i ? "x" : "y");
                if (
                  (i &&
                    ((t.onPoint || t).getRadii(0, 0, t),
                    t.onPoint && (t.radii = t.onPoint.radii)),
                  o > 0)
                ) {
                  let i = e.length;
                  for (; i--; )
                    if (i6(e[i]) && this.dataMin <= e[i] && e[i] <= this.max) {
                      let o = (t.radii && t.radii[i]) || 0;
                      (r = Math.min((e[i] - s) * n - o, r)),
                        (a = Math.max((e[i] - s) * n + o, a));
                    }
                }
              }
            }),
            l &&
              o > 0 &&
              !this.logarithmic &&
              ((a -= t),
              (n *= (t + Math.max(0, r) - Math.min(a, t)) / t),
              [
                ["min", "userMin", r],
                ["max", "userMax", a],
              ].forEach((t) => {
                void 0 === i8(this.options[t[0]], this[t[1]]) &&
                  (this[t[0]] += t[2] / n);
              })));
        }
        function i4() {
          let {
              ticks: t,
              tickPositions: e,
              dataMin: i = 0,
              dataMax: s = 0,
              categories: o,
            } = this,
            r = this.options.type;
          if (
            (o?.length || "category" === r) &&
            this.series.find((t) => t.bubblePadding)
          ) {
            let o = e.length;
            for (; o--; ) {
              let r = t[e[o]],
                a = r.pos || 0;
              (a > s || a < i) && r.label?.hide();
            }
          }
        }
        class i5 extends i$ {
          static compose(t, e, i) {
            iX.compose(e, i),
              i7(iZ, "Series.Bubble") &&
                (iJ(t, "foundExtremes", i9), iJ(t, "afterRender", i4));
          }
          animate(t) {
            !t &&
              this.points.length < this.options.animationLimit &&
              this.points.forEach(function (t) {
                let { graphic: e, plotX: i = 0, plotY: s = 0 } = t;
                e &&
                  e.width &&
                  (this.hasRendered ||
                    e.attr({ x: i, y: s, width: 1, height: 1 }),
                  e.animate(this.markerAttribs(t), this.options.animation));
              }, this);
          }
          getRadii() {
            let t = this.getColumn("z"),
              e = this.getColumn("y"),
              i = [],
              s,
              o,
              r,
              a = this.chart.bubbleZExtremes,
              { minPxSize: n, maxPxSize: l } = this.getPxExtremes();
            if (!a) {
              let t,
                e = Number.MAX_VALUE,
                i = -Number.MAX_VALUE;
              this.chart.series.forEach((s) => {
                if (s.bubblePadding && s.reserveSpace()) {
                  let o = (s.onPoint || s).getZExtremes();
                  o &&
                    ((e = Math.min(i8(e, o.zMin), o.zMin)),
                    (i = Math.max(i8(i, o.zMax), o.zMax)),
                    (t = !0));
                }
              }),
                t
                  ? ((a = { zMin: e, zMax: i }),
                    (this.chart.bubbleZExtremes = a))
                  : (a = { zMin: 0, zMax: 0 });
            }
            for (o = 0, s = t.length; o < s; o++)
              (r = t[o]),
                i.push(this.getRadius(a.zMin, a.zMax, n, l, r, e && e[o]));
            this.radii = i;
          }
          getRadius(t, e, i, s, o, r) {
            let a = this.options,
              n = "width" !== a.sizeBy,
              l = a.zThreshold,
              h = e - t,
              p = 0.5;
            if (null === r || null === o) return null;
            if (i6(o)) {
              if (
                (a.sizeByAbsoluteValue &&
                  ((o = Math.abs(o - l)),
                  (e = h = Math.max(e - l, Math.abs(t - l))),
                  (t = 0)),
                o < t)
              )
                return i / 2 - 1;
              h > 0 && (p = (o - t) / h);
            }
            return (
              n && p >= 0 && (p = Math.sqrt(p)), Math.ceil(i + p * (s - i)) / 2
            );
          }
          hasData() {
            return !!this.dataTable.rowCount;
          }
          markerAttribs(t, e) {
            let i = super.markerAttribs(t, e),
              { height: s = 0, width: o = 0 } = i;
            return this.chart.inverted
              ? i2(i, { x: (t.plotX || 0) - o / 2, y: (t.plotY || 0) - s / 2 })
              : i;
          }
          pointAttribs(t, e) {
            let i = this.options.marker,
              s = i?.fillOpacity,
              o = iK.prototype.pointAttribs.call(this, t, e);
            return (o["fill-opacity"] = s ?? 1), o;
          }
          translate() {
            super.translate.call(this), this.getRadii(), this.translateBubble();
          }
          translateBubble() {
            let { data: t, options: e, radii: i } = this,
              { minPxSize: s } = this.getPxExtremes(),
              o = t.length;
            for (; o--; ) {
              let r = t[o],
                a = i ? i[o] : 0;
              "z" === this.zoneAxis &&
                (r.negative = (r.z || 0) < (e.zThreshold || 0)),
                i6(a) && a >= s / 2
                  ? ((r.marker = i2(r.marker, {
                      radius: a,
                      width: 2 * a,
                      height: 2 * a,
                    })),
                    (r.dlBox = {
                      x: r.plotX - a,
                      y: r.plotY - a,
                      width: 2 * a,
                      height: 2 * a,
                    }))
                  : ((r.shapeArgs = r.plotY = r.dlBox = void 0),
                    (r.isInside = !1));
            }
          }
          getPxExtremes() {
            let t = Math.min(this.chart.plotWidth, this.chart.plotHeight),
              e = (e) => {
                let i;
                return (
                  "string" == typeof e &&
                    ((i = /%$/.test(e)), (e = parseInt(e, 10))),
                  i ? (t * e) / 100 : e
                );
              },
              i = e(i8(this.options.minSize, 8)),
              s = Math.max(e(i8(this.options.maxSize, "20%")), i);
            return { minPxSize: i, maxPxSize: s };
          }
          getZExtremes() {
            let t = this.options,
              e = this.getColumn("z").filter(i6);
            if (e.length) {
              let i = i8(
                  t.zMin,
                  i1(
                    i0(e),
                    !1 === t.displayNegative
                      ? t.zThreshold || 0
                      : -Number.MAX_VALUE,
                    Number.MAX_VALUE
                  )
                ),
                s = i8(t.zMax, iQ(e));
              if (i6(i) && i6(s)) return { zMin: i, zMax: s };
            }
          }
          searchKDTree(t, e, i, s = i_, o = i_) {
            return (
              (s = (t, e, i) => {
                let s = t[i] || 0,
                  o = e[i] || 0,
                  r,
                  a = !1;
                return (
                  s === o
                    ? (r = t.index > e.index ? t : e)
                    : s < 0 && o < 0
                    ? ((r =
                        s - (t.marker?.radius || 0) >=
                        o - (e.marker?.radius || 0)
                          ? t
                          : e),
                      (a = !0))
                    : (r = s < o ? t : e),
                  [r, a]
                );
              }),
              (o = (t, e, i) => (!i && t > e) || t < e),
              super.searchKDTree(t, e, i, s, o)
            );
          }
        }
        (i5.defaultOptions = i3(i$.defaultOptions, {
          dataLabels: {
            formatter: function () {
              let { numberFormatter: t } = this.series.chart,
                { z: e } = this.point;
              return i6(e) ? t(e, -1) : "";
            },
            inside: !0,
            verticalAlign: "middle",
          },
          animationLimit: 250,
          marker: {
            lineColor: null,
            lineWidth: 1,
            fillOpacity: 0.5,
            radius: null,
            states: { hover: { radiusPlus: 0 } },
            symbol: "circle",
          },
          minSize: 8,
          maxSize: "20%",
          softThreshold: !1,
          states: { hover: { halo: { size: 5 } } },
          tooltip: { pointFormat: "({point.x}, {point.y}), Size: {point.z}" },
          turboThreshold: 0,
          zThreshold: 0,
          zoneAxis: "z",
        })),
          i2(i5.prototype, {
            alignDataLabel: iq.alignDataLabel,
            applyZones: i_,
            bubblePadding: !0,
            isBubble: !0,
            keysAffectYAxis: ["y"],
            pointArrayMap: ["y", "z"],
            pointClass: iF,
            parallelArrays: ["x", "y", "z"],
            trackerGroups: ["group", "dataLabelsGroup"],
            specialGroup: "group",
            zoneAxis: "z",
          }),
          iJ(i5, "updatedData", (t) => {
            delete t.target.chart.bubbleZExtremes;
          }),
          iJ(i5, "remove", (t) => {
            delete t.target.chart.bubbleZExtremes;
          }),
          W().registerSeriesType("bubble", i5);
        let st = i5,
          {
            seriesTypes: {
              map: {
                prototype: {
                  pointClass: { prototype: se },
                },
              },
            },
          } = W(),
          { extend: si } = L();
        class ss extends iF {
          isValid() {
            return "number" == typeof this.z;
          }
        }
        si(ss.prototype, {
          applyOptions: se.applyOptions,
          getProjectedBounds: se.getProjectedBounds,
        });
        let {
            seriesTypes: {
              map: { prototype: so },
              mappoint: { prototype: sr },
            },
          } = W(),
          { extend: sa, merge: sn } = L();
        class sl extends st {
          constructor() {
            super(...arguments), (this.clearBounds = so.clearBounds);
          }
          searchPoint(t, e) {
            return this.searchKDTree(
              {
                plotX: t.chartX - this.chart.plotLeft,
                plotY: t.chartY - this.chart.plotTop,
              },
              e,
              t
            );
          }
          translate() {
            sr.translate.call(this), this.getRadii(), this.translateBubble();
          }
        }
        (sl.defaultOptions = sn(st.defaultOptions, {
          lineWidth: 0,
          animationLimit: 500,
          joinBy: "hc-key",
          tooltip: { pointFormat: "{point.name}: {point.z}" },
        })),
          sa(sl.prototype, {
            type: "mapbubble",
            axisTypes: ["colorAxis"],
            getProjectedBounds: so.getProjectedBounds,
            isCartesian: !1,
            pointArrayMap: ["z"],
            pointClass: ss,
            processData: so.processData,
            projectPoint: sr.projectPoint,
            kdAxisArray: ["plotX", "plotY"],
            setData: so.setData,
            setOptions: so.setOptions,
            updateData: so.updateData,
            useMapGeometry: !0,
            xyFromShape: !0,
          }),
          W().registerSeriesType("mapbubble", sl);
        let {
            scatter: {
              prototype: { pointClass: sh },
            },
          } = W().seriesTypes,
          { clamp: sp, defined: sd, extend: sc, pick: su } = L();
        class sm extends sh {
          applyOptions(t, e) {
            return (
              (this.isNull || null === this.value) && delete this.color,
              super.applyOptions(t, e),
              (this.formatPrefix =
                this.isNull || null === this.value ? "null" : "point"),
              this
            );
          }
          getCellAttributes() {
            let t = this.series,
              e = t.options,
              i = (e.colsize || 1) / 2,
              s = (e.rowsize || 1) / 2,
              o = t.xAxis,
              r = t.yAxis,
              a = this.options.marker || t.options.marker,
              n = t.pointPlacementToXValue(),
              l = su(this.pointPadding, e.pointPadding, 0),
              h = {
                x1: sp(
                  Math.round(
                    o.len - o.translate(this.x - i, !1, !0, !1, !0, -n)
                  ),
                  -o.len,
                  2 * o.len
                ),
                x2: sp(
                  Math.round(
                    o.len - o.translate(this.x + i, !1, !0, !1, !0, -n)
                  ),
                  -o.len,
                  2 * o.len
                ),
                y1: sp(
                  Math.round(r.translate(this.y - s, !1, !0, !1, !0)),
                  -r.len,
                  2 * r.len
                ),
                y2: sp(
                  Math.round(r.translate(this.y + s, !1, !0, !1, !0)),
                  -r.len,
                  2 * r.len
                ),
              };
            for (let t of [
              ["width", "x"],
              ["height", "y"],
            ]) {
              let e = t[0],
                i = t[1],
                s = i + "1",
                n = i + "2",
                p = Math.abs(h[s] - h[n]),
                d = (a && a.lineWidth) || 0,
                c = Math.abs(h[s] + h[n]) / 2,
                u = a && a[e];
              if (sd(u) && u < p) {
                let t = u / 2 + d / 2;
                (h[s] = c - t), (h[n] = c + t);
              }
              l &&
                ((("x" === i && o.reversed) || ("y" === i && !r.reversed)) &&
                  ((s = n), (n = i + "1")),
                (h[s] += l),
                (h[n] -= l));
            }
            return h;
          }
          haloPath(t) {
            if (!t) return [];
            let {
              x: e = 0,
              y: i = 0,
              width: s = 0,
              height: o = 0,
            } = this.shapeArgs || {};
            return [
              ["M", e - t, i - t],
              ["L", e - t, i + o + t],
              ["L", e + s + t, i + o + t],
              ["L", e + s + t, i - t],
              ["Z"],
            ];
          }
          isValid() {
            return this.value !== 1 / 0 && this.value !== -1 / 0;
          }
        }
        sc(sm.prototype, {
          dataLabelOnNull: !0,
          moveToTopOnHover: !0,
          ttBelow: !1,
        });
        let { isNumber: sg } = L(),
          { doc: sf } = L(),
          { defined: sb, pick: sy } = L(),
          {
            series: sx,
            seriesTypes: { column: sM, scatter: sv },
          } = W(),
          {
            prototype: { symbols: sw },
          } = tN(),
          {
            addEvent: sC,
            extend: sT,
            fireEvent: sL,
            isNumber: sP,
            merge: sA,
            pick: sk,
          } = L(),
          { colorFromPoint: sj, getContext: sz } = {
            colorFromPoint: function (t, e) {
              let i = e.series.colorAxis;
              if (i) {
                let s = i
                  .toColor(t || 0, e)
                  .split(")")[0]
                  .split("(")[1]
                  .split(",")
                  .map((t) => sy(parseFloat(t), parseInt(t, 10)));
                return (
                  (s[3] = 255 * sy(s[3], 1)),
                  (sb(t) && e.visible) || (s[3] = 0),
                  s
                );
              }
              return [0, 0, 0, 0];
            },
            getContext: function (t) {
              let { canvas: e, context: i } = t;
              return e && i
                ? (i.clearRect(0, 0, e.width, e.height), i)
                : ((t.canvas = sf.createElement("canvas")),
                  (t.context =
                    t.canvas.getContext("2d", { willReadFrequently: !0 }) ||
                    void 0),
                  t.context);
            },
          };
        class sS extends sv {
          constructor() {
            super(...arguments),
              (this.valueMax = NaN),
              (this.valueMin = NaN),
              (this.isDirtyCanvas = !0);
          }
          drawPoints() {
            let t = this,
              e = t.options,
              i = e.interpolation,
              s = e.marker || {};
            if (i) {
              let { image: e, chart: i, xAxis: s, yAxis: o } = t,
                { reversed: r = !1, len: a } = s,
                { reversed: n = !1, len: l } = o,
                h = { width: a, height: l };
              if (!e || t.isDirtyData || t.isDirtyCanvas) {
                let a = sz(t),
                  {
                    canvas: l,
                    options: { colsize: p = 1, rowsize: d = 1 },
                    points: c,
                    points: { length: u },
                  } = t,
                  m = i.colorAxis && i.colorAxis[0];
                if (l && a && m) {
                  let { min: m, max: g } = s.getExtremes(),
                    { min: f, max: b } = o.getExtremes(),
                    y = g - m,
                    x = b - f,
                    M = Math.round((y / p / 8) * 8),
                    v = Math.round((x / d / 8) * 8),
                    [w, C] = [
                      [M, M / y, r, "ceil"],
                      [v, v / x, !n, "floor"],
                    ].map(([t, e, i, s]) =>
                      i ? (i) => Math[s](t - e * i) : (t) => Math[s](e * t)
                    ),
                    T = (l.width = M + 1),
                    L = T * (l.height = v + 1),
                    P = (u - 1) / L,
                    A = new Uint8ClampedArray(4 * L),
                    k = (t, e) => 4 * Math.ceil(T * C(e - f) + w(t - m));
                  t.buildKDTree();
                  for (let t = 0; t < L; t++) {
                    let e = c[Math.ceil(P * t)],
                      { x: i, y: s } = e;
                    A.set(sj(e.value, e), k(i, s));
                  }
                  a.putImageData(new ImageData(A, T), 0, 0),
                    e
                      ? e.attr({ ...h, href: l.toDataURL("image/png", 1) })
                      : ((t.directTouch = !1),
                        (t.image = i.renderer
                          .image(l.toDataURL("image/png", 1))
                          .attr(h)
                          .add(t.group)));
                }
                t.isDirtyCanvas = !1;
              } else (e.width !== a || e.height !== l) && e.attr(h);
            } else
              (s.enabled || t._hasPointMarkers) &&
                (sx.prototype.drawPoints.call(t),
                t.points.forEach((e) => {
                  e.graphic &&
                    (e.graphic[t.chart.styledMode ? "css" : "animate"](
                      t.colorAttribs(e)
                    ),
                    null === e.value &&
                      e.graphic.addClass("highcharts-null-point"));
                }));
          }
          getExtremes() {
            let { dataMin: t, dataMax: e } = sx.prototype.getExtremes.call(
              this,
              this.getColumn("value")
            );
            return (
              sP(t) && (this.valueMin = t),
              sP(e) && (this.valueMax = e),
              sx.prototype.getExtremes.call(this)
            );
          }
          getValidPoints(t, e) {
            return sx.prototype.getValidPoints.call(this, t, e, !0);
          }
          hasData() {
            return !!this.dataTable.rowCount;
          }
          init() {
            super.init.apply(this, arguments);
            let t = this.options;
            (t.pointRange = sk(t.pointRange, t.colsize || 1)),
              (this.yAxis.axisPointRange = t.rowsize || 1),
              (sw.ellipse = sw.circle),
              t.marker && sP(t.borderRadius) && (t.marker.r = t.borderRadius);
          }
          markerAttribs(t, e) {
            let i = t.shapeArgs || {};
            if (t.hasImage) return { x: t.plotX, y: t.plotY };
            if (e && "normal" !== e) {
              let s = t.options.marker || {},
                o = this.options.marker || {},
                r = o.states?.[e] || {},
                a = s.states?.[e] || {},
                n =
                  (a.width || r.width || i.width || 0) +
                  (a.widthPlus || r.widthPlus || 0),
                l =
                  (a.height || r.height || i.height || 0) +
                  (a.heightPlus || r.heightPlus || 0);
              return {
                x: (i.x || 0) + ((i.width || 0) - n) / 2,
                y: (i.y || 0) + ((i.height || 0) - l) / 2,
                width: n,
                height: l,
              };
            }
            return i;
          }
          pointAttribs(t, e) {
            let i = sx.prototype.pointAttribs.call(this, t, e),
              s = this.options || {},
              o = this.chart.options.plotOptions || {},
              r = o.series || {},
              a = o.heatmap || {},
              n =
                t?.options.borderColor ||
                s.borderColor ||
                a.borderColor ||
                r.borderColor,
              l =
                t?.options.borderWidth ||
                s.borderWidth ||
                a.borderWidth ||
                r.borderWidth ||
                i["stroke-width"];
            if (
              ((i.stroke =
                t?.marker?.lineColor || s.marker?.lineColor || n || this.color),
              (i["stroke-width"] = l),
              e && "normal" !== e)
            ) {
              let o = sA(
                s.states?.[e],
                s.marker?.states?.[e],
                t?.options.states?.[e] || {}
              );
              (i.fill =
                o.color ||
                j()
                  .parse(i.fill)
                  .brighten(o.brightness || 0)
                  .get()),
                (i.stroke = o.lineColor || i.stroke);
            }
            return i;
          }
          translate() {
            let { borderRadius: t, marker: e } = this.options,
              i = e?.symbol || "rect",
              s = sw[i] ? i : "rect",
              o = -1 !== ["circle", "square"].indexOf(s);
            for (let e of (this.generatePoints(), this.points)) {
              let r = e.getCellAttributes(),
                a = Math.min(r.x1, r.x2),
                n = Math.min(r.y1, r.y2),
                l = Math.max(Math.abs(r.x2 - r.x1), 0),
                h = Math.max(Math.abs(r.y2 - r.y1), 0);
              if (
                ((e.hasImage =
                  0 === (e.marker?.symbol || i || "").indexOf("url")),
                o)
              ) {
                let t = Math.abs(l - h);
                (a = Math.min(r.x1, r.x2) + (l < h ? 0 : t / 2)),
                  (n = Math.min(r.y1, r.y2) + (l < h ? t / 2 : 0)),
                  (l = h = Math.min(l, h));
              }
              e.hasImage && (e.marker = { width: l, height: h }),
                (e.plotX = e.clientX = (r.x1 + r.x2) / 2),
                (e.plotY = (r.y1 + r.y2) / 2),
                (e.shapeType = "path"),
                (e.shapeArgs = sA(
                  !0,
                  { x: a, y: n, width: l, height: h },
                  { d: sw[s](a, n, l, h, { r: sP(t) ? t : 0 }) }
                ));
            }
            sL(this, "afterTranslate");
          }
        }
        (sS.defaultOptions = sA(sv.defaultOptions, {
          animation: !1,
          borderRadius: 0,
          borderWidth: 0,
          interpolation: !1,
          nullColor: "#f7f7f7",
          dataLabels: {
            formatter: function () {
              let { numberFormatter: t } = this.series.chart,
                { value: e } = this.point;
              return sg(e) ? t(e, -1) : "";
            },
            inside: !0,
            verticalAlign: "middle",
            crop: !1,
            overflow: "allow",
            padding: 0,
          },
          marker: {
            symbol: "rect",
            radius: 0,
            lineColor: void 0,
            states: { hover: { lineWidthPlus: 0 }, select: {} },
          },
          clip: !0,
          pointRange: null,
          tooltip: { pointFormat: "{point.x}, {point.y}: {point.value}<br/>" },
          states: { hover: { halo: !1, brightness: 0.2 } },
          legendSymbol: "rectangle",
        })),
          sC(sS, "afterDataClassLegendClick", function () {
            (this.isDirtyCanvas = !0), this.drawPoints();
          }),
          sT(sS.prototype, {
            axisTypes: tP.seriesMembers.axisTypes,
            colorKey: tP.seriesMembers.colorKey,
            directTouch: !0,
            getExtremesFromAll: !0,
            keysAffectYAxis: ["y"],
            parallelArrays: tP.seriesMembers.parallelArrays,
            pointArrayMap: ["y", "value"],
            pointClass: sm,
            specialGroup: "group",
            trackerGroups: tP.seriesMembers.trackerGroups,
            alignDataLabel: sM.prototype.alignDataLabel,
            colorAttribs: tP.seriesMembers.colorAttribs,
            getSymbol: sx.prototype.getSymbol,
          }),
          tP.compose(sS),
          W().registerSeriesType("heatmap", sS);
        /**
         * @license Highmaps JS v12.3.0 (2025-06-21)
         * @module highcharts/modules/map
         * @requires highcharts
         *
         * Highmaps as a plugin for Highcharts or Highcharts Stock.
         *
         * (c) 2011-2025 Torstein Honsi
         *
         * License: www.highcharts.com/license
         */ let sI = L();
        (sI.ColorMapComposition = tP),
          (sI.MapChart = sI.MapChart || tY),
          (sI.MapNavigation = sI.MapNavigation || tM),
          (sI.MapView = sI.MapView || eU),
          (sI.Projection = sI.Projection || eL),
          (sI.mapChart = sI.Map = sI.MapChart.mapChart),
          (sI.maps = sI.MapChart.maps),
          (sI.geojson = t4.geojson),
          (sI.topo2geo = t4.topo2geo),
          t4.compose(sI.Chart),
          sl.compose(sI.Axis, sI.Chart, sI.Legend),
          tM.compose(tY, sI.Pointer, sI.SVGRenderer),
          eU.compose(tY);
        let sB = L();
        return C.default;
      })()
  )
);
